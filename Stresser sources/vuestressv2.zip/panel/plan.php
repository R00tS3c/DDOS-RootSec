<?php
header("Location: https://t.me/champtelnet");
exit;
?>
