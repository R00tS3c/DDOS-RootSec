# Defcon-API-Panel-Ddos-

ENG: 

Hello, I decided to make a script that is run on Defcon.pro API.
Script set in the 'connect_db.php' file all you need to do is type in your data 'Username & Password'.
Insert the script on your domain and enjoy :)

ME & RS: 

Pozdrav, odlučio sam da napravim skriptu koja se vodi na Defcon.pro API.
Skriptu podešavate u 'connect_db.php' fajl sve sto je potrebno jeste da upisete vase podatke 'Username & Password'.
Ubacite skriptu na vas domen i uzivate :)
