<footer>
	<div class="wrapper">
		<span class="copyright">
			<?php echo 'Copyright &copy '.date('Y').' Hop Stresser'; ?>
		</span>
	</div>
</footer>