<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta content="width=device-width,initial-scale=1,shrink-to-fit=no" name="viewport">
    <meta content="free stresser, top stresser, stressthem, stress them, stress denial of service, dos, stresser app,booter,ip stresser, stresser, booter, ddos tool, ddos attack, ddos attack online, layer7 ddos, layer4 ddos, api, api access, network stresser, network booter, slowloris, best Booter, best stresser, strongest stresser, powerful booter, ddoser, ddos, gbooter, top booter, ipstress, booter, stresser, network stresser, network booter, #Booter, BROWSER, captcha bypass, drdos,ssyn, dns amplification" name="keywords">
    <meta content="index, follow" name="robots">
    <meta property="og:title" content="The most advanced DDoS tools on the DDoS market."/>
    <meta property="og:image" content="assets/media/favicon/favicon-32x32.png"/>
    <meta property="og:type" content="website"/>
    <title>Handled Maintenance</title>
    <link rel="shortcut icon" href="assets/media/favicon/favicon.ico"/>
    <!--end::Fonts-->
    <link href="assets/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css"/>
    <link href="assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/style.bundle.css" rel="stylesheet" type="text/css"/>
    <!--end::Global Stylesheets Bundle-->
    <link rel="preconnect" href="https://ajax.cloudflare.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
</head>
<body id="kt_body" class="aside-enabled">
<!--begin::wrapper -->
<div class="wrapper d-flex flex-column">
    <!--begin::Header-->
    <div class="header align-items-stretch">
        <!--begin::Brand-->
        <div class="header-brand">
            <!--begin::Logo-->
            <a href="index"><img alt="Logo" src="assets/media/logos/logo.png" class="h-35px h-lg-45px mx-xxl-10"/></a>
            <span class="fs-5 fw-bold">stresse.re</span>
            <!--end::Logo-->
        </div>
        <!--end::Brand-->
    </div>
    <!--end::Header-->
</div>
<!--end::wrapper -->
<!-- begin:: Login -->
<div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="d-flex flex-column flex-column-fluid-jum flex-lg-row justify-content-center">
        <div class="d-flex flex-center w-lg-50 p-10">
            <!--begin::Card-->
            <div class="card rounded-1 w-md-1000px">
                <!--begin::Card body-->
                <div class="card-body p-10 p-lg-6 fs-3 fw-bold text-center">
                    Technical work in progress.
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
        </div>
    </div>
    <!--end::Page-->
</div>
<!-- end:: Login -->
<!--begin::Footer-->
<div class="footer py-4 d-flex flex-lg-column " id="kt_footer">
    <!--begin::Container-->
    <div class=" container-fluid  d-flex flex-column flex-md-row align-items-center justify-content-between">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-bold me-1">2023&copy;</span>
            <a href="." target="_blank" class="text-gray-800 text-hover-primary">Home</a>
        </div>
        <!--end::Copyright-->
        <!--begin::Menu-->
        <ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">
            <li class="menu-item">
                <a href="#" target="_blank" class="menu-link px-2">Support</a>
            </li>
            <li class="menu-item">
                <a href="purchase" target="_blank" class="menu-link px-2">Purchase</a>
            </li>
        </ul>
        <!--end::Menu-->
    </div>
    <!--end::Container-->
</div>
<!--end::Footer-->
<!--end::Wrapper-->
<!--end::Page-->
<!--end::Root-->
<!--begin::Scrolltop-->
<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
    <i class="ki-duotone ki-arrow-up">
        <span class="path1"></span><span class="path2"></span>
    </i>
</div>
<!--end::Scrolltop-->
<!--begin::Javascript-->
<!--begin::Main-JS-->
<script src="assets/js/scripts.bundle.js"></script>
<script src="assets/plugins/global/plugins.bundle.js"></script>
<!--end::Main-JS-->
<script src="assets/js/custom/home.js"></script>
<script src="assets/plugins/custom/datatables/datatables.bundle.js"></script>
<!--end::Javascript-->
</body>
</html>