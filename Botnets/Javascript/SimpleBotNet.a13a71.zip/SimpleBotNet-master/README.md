# SimpleBotNet
This is an idea for a simple botnet using websockets, C# as the stub Node.js as a connector

There is not much to add, look at the code and build the client using visual studio.

TODO:
- auto reconnect on the client side
- nice frontend
- frontend login
- secure connection
- maybe clients for Linux/Mac OS?
