<?php
header("404 Not Found", true, 404);
include("../notFound.php")
?>