#pragma once

int conn_pid;

void killer_init();
void killer_kill();
