# Crucial CnC
Crucial is a HTTP Mirai C&C for better access for C2 users and such..\

# How to Build
```bash
sudo apt update -y
sudo apt install golang mysql -y
go build


```

# 
