#pragma once

#define HTTP_SERVER "78.142.18.95"
#define HTTP_PORT 80

#define TFTP_SERVER "78.142.18.95"
