#pragma once

#ifdef DEBUG
#define debug(fmt, ...) printf("[aterna] " fmt, ##__VA_ARGS__)
#endif

#ifndef DEBUG
#define debug(...)
#endif
