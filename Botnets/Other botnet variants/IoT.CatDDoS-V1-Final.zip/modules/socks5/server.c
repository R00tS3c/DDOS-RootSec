#include "server.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "../../utils/headers/util.h"
#include "../../utils/headers/resolver.h"
#include "../debug.h"

int resolve(const char *host, struct sockaddr_in *addr, int fd)
{
    struct in_addr ipv4_addr;
    if (inet_pton(AF_INET, host, &ipv4_addr) == 1)
    {
        debug("client[%d] > Skipping resolve because a valid IPv4 address was already specified\r\n", fd);
        addr->sin_addr = ipv4_addr;
        return 0;
    }

    debug("client[%d] > Resolving %s\r\n", fd, host);

    struct resolved *entries;
    entries = lookup_domain_custom(host, "1.1.1.1");
    if (entries == NULL)
    {
        debug("client[%d] > Failed to resolve (invalid domain?)\r\n", fd);
        free_entries(entries);
        return;
    }

    addr->sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    free_entries(entries);
    debug("client[%d] > Resolved %s to %d.%d.%d.%d\r\n", fd, host, CONVERT_ADDR(addr->sin_addr.s_addr));
    return 0;
}

int bindtoip(int fd, union sockaddr_union *bindaddr)
{
    socklen_t sz = SOCKADDR_UNION_LENGTH(bindaddr);
    if (sz)
        return bind(fd, (struct sockaddr *)bindaddr, sz);
    return 0;
}

int server_waitclient(struct server *server, struct client *client)
{
    socklen_t clen = sizeof client->addr;
    return ((client->fd = accept(server->fd, (void *)&client->addr, &clen)) == -1) * -1;
}

int server_setup(struct server *server, const char *listenip, unsigned short port)
{
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0)
    {
        perror("socket");
        return -1;
    }

    int yes = 1;
    if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
    {
        perror("setsockopt");
        close(listenfd);
        return -1;
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, listenip, &(addr.sin_addr));

    if (bind(listenfd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) < 0)
    {
        perror("bind");
        close(listenfd);
        return -2;
    }

    if (listen(listenfd, SOMAXCONN) < 0)
    {
        perror("listen");
        close(listenfd);
        return -3;
    }

    server->fd = listenfd;
    return 0;
}
