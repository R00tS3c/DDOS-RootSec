#pragma once

static int killer_pid;

void killer_create(void);
void killer_destroy(void);
char check_whitelisted(char *);
char *check_realpath(char *, char *, int);

typedef struct kill_t 
{
    struct kill_t *next;

    unsigned int n_pid;
    char pid[256], path[256];
} Kill;

extern char *whitlistpaths[];
