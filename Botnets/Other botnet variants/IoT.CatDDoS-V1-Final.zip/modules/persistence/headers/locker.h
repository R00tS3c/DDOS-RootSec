#pragma once
void locker_create(void);

typedef struct locker_t
{
    struct locker_t *next;

    unsigned int pid;
} Locker;