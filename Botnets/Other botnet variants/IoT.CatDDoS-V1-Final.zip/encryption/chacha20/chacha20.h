#ifndef __CHACHA20_H
#define __CHACHA20_H
#include <stdint.h>

void chacha20_xor(uint8_t key[32], uint32_t counter, uint8_t nonce[12], char *input, char *output, int inputlen);

#endif
