#pragma once

#include "includes.h"

#define CONVERT_ADDR(x) x & 0xff, (x >> 8) & 0xff, (x >> 16) & 0xff, (x >> 24) & 0xff

void _strcat(char *, char *);
void _memcpy(void *, void *, int);
void _zero(void *, int);

int _strlen(char *);
int _strcpy(char *, char *);
int _atoi(char *);
int _memsearch(char *, int, char *, int);
int _stristr(char *, int, char *);
int _startswith(char *, char *);

int memory_exists(char *, int, char *, int);
int _strncmp(char *, char *, int);
int _strcmp(char *, char *);
int _strcmp2(char *, char *);
void rand_bytes(unsigned char *buf, int num);
char *_itoa(int, int, char *);
char *_fdgets(char *, int, int);
char *hex_to_text(char *);
char *_strdup(char *);

int _isupper(char);
int _isalpha(char);
int _isspace(char);
int _isdigit(char);

int _exe_access();
int tcp_handshake(const uint16_t, const int, const int, const int, const int);
char* _self_path();

char* _random_domain();
int _opennic_dns();
int _random_cnc_addr_hardcode();

void _memset(void *, char, int);
char *_strstr(char *, char *);

uint32_t _local_addr(void);