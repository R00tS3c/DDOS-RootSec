#pragma once

#include "includes.h"

struct resolved {
    uint8_t addrs_len;
    uint32_t *addrs;
};

void domain_to_hostname(char *, char *);
struct resolved *lookup_domain(char *);
void free_entries(struct resolved *);
struct resolved *lookup_domain_custom(char *domain, char *dns_server);