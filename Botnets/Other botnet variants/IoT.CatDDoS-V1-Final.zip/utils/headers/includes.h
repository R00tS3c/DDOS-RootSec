#pragma once

#include <unistd.h>
#include <stdint.h>
#include <stdarg.h>

#define INET_ADDR(o1, o2, o3, o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))
extern uint32_t LOCAL_ADDR;

enum
{
    STDIN = 0,
    STDOUT = 1,
    STDERR = 2,

    TRUE = 1,
    FALSE = 0,

    ENSURE_PORT = 8345,
    C2_PORT = 35342,

    STAGE_SETUP = 0,
    STAGE_READ = 1,
    STAGE_DISCONNECT = 2,
};

static int enable = 1;

#define REUSE_ADDR(fd) (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable)))
#define REUSE_PORT(fd) (setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &enable, sizeof(enable)))
#define NONBLOCK(fd) (fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0)))

#define LOCALHOST (INET_ADDR(127, 0, 0, 1))
