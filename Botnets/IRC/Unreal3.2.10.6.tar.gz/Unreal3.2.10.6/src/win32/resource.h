//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Win32GUI.rc
//
#define VER_UNREAL                      1
#define MANIFEST_RESOURCE_ID            2
#define ICO_MAIN                        129
#define BMP_LOGO                        130
#define BMP_BAR                         133
#define CUR_HAND                        136
#define MENU_ABOUT                      137
#define MENU_CONFIG                     141
#define MENU_REHASH                     144
#define MENU_SYSTRAY                    145
#define MENU_CONTEXT                    146
#define IDB_BITMAP1                     150
#define IDC_BAR                         1103
#define IDC_TOOLBAR                     1104
#define IDC_STATUS                      1105
#define IDC_TEXT                        1107
#define IDC_EMAIL                       1108
#define IDC_URL                         1109
#define IDC_TREE                        1111
#define IDC_CHANNELS                    1112
#define IDC_CLIENTS                     1113
#define IDC_SERVERS                     1114
#define IDC_INVISO                      1115
#define IDC_OPERS                       1116
#define IDC_UNKNOWN                     1117
#define IDC_MAXCLIENTS                  1118
#define IDC_LCLIENTS                    1122
#define IDC_LSERVERS                    1123
#define IDC_LMAXCLIENTS                 1124
#define IDC_UPTIME                      1125
#define IDC_CONFIGERROR                 1126
#define IDC_BOLD                        1130
#define IDC_UNDERLINE                   1131
#define IDC_FIND                        1132
#define IDFIND                          1133
#define IDC_FINDTEXT                    1135
#define IDC_GOTO                        1135
#define IDC_MATCHWHOLE                  1137
#define IDC_MATCHCASE                   1138
#define IDC_DIRUP                       1139
#define IDC_DIRDOWN                     1140
#define IDC_COLOR                       1141
#define IDC_BGCOLOR			1142
#define IDC_WHITE                       1163
#define IDC_BLACK                       1164
#define IDC_DARKBLUE                    1165
#define IDC_DARKGREEN                   1166
#define IDC_PASS                        1166
#define IDC_RED                         1167
#define IDC_DARKRED                     1168
#define IDC_PURPLE                      1169
#define IDC_ORANGE                      1170
#define IDC_YELLOW                      1171
#define IDC_GREEN                       1172
#define IDC_VDARKGREEN                  1173
#define IDC_LIGHTBLUE                   1174
#define IDC_BLUE                        1175
#define IDC_PINK                        1176
#define IDC_DARKGRAY                    1177
#define IDC_GRAY                        1178
#define IDM_INFO                        40026
#define IDM_CREDITS                     40027
#define IDM_DAL                         40028
#define IDM_LICENSE                     40029
#define IDM_HELP                        40030
#define IDM_SAVE                        40031
#define IDM_REDO                        40032
#define IDM_SMOTD			40036
#define IDM_CONF                        40037
#define IDM_MOTD                        40038
#define IDM_BOTMOTD                     40039
#define IDM_OPERMOTD                    40040
#define IDM_RULES                       40041
#define IDM_RHALL                       40042
#define IDM_RHCONF                      40044
#define IDM_RHMOTD                      40045
#define IDM_RHOMOTD                     40046
#define IDM_RHBMOTD                     40047
#define IDM_RHRULES                     40048
#define IDM_REHASH                      40049
#define IDM_STATUS                      40050
#define IDM_CONFIG                      40051
#define IDM_ABOUT                       40052
#define IDM_SHUTDOWN                    40053
#define IDM_UNDO                        40054
#define IDM_CUT                         40055
#define IDM_COPY                        40056
#define IDM_PASTE                       40057
#define IDM_DELETE                      40058
#define IDM_SELECTALL                   40059
#define IDM_NEW                         40060
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         40061
#define _APS_NEXT_CONTROL_VALUE         1167
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
