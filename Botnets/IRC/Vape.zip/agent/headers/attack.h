void attack_manage(char[]);
