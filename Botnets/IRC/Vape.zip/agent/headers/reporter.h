void report_working(char *);
