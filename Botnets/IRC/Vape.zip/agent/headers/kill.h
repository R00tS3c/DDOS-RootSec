void killer_init();
void killer_kill();
