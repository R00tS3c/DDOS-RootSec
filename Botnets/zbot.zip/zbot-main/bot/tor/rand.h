#pragma once

void rand_init(void);
uint32_t rand_next(void);
void rand_string(char *str, int len);
