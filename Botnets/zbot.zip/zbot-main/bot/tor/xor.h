#pragma once

#include <stdint.h>

char *xor_decode(char *, int);
