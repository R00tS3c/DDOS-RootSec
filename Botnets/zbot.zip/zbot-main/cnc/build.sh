gcc src/*.c -DDEBUG -lpthread $(mysql_config --libs)
