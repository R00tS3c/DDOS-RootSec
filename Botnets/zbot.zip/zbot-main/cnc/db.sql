create database `backdoorin`;

use backdoorin;

CREATE TABLE `users` (
    `username` varchar(32) NOT NULL,
    `password` varchar(32) NOT NULL,
    KEY `username` (`username`)
);

INSERT INTO users(username, password) VALUES('xthanos', 'zs4lyfe!');
INSERT INTO users(username, password) VALUES('bank', 'bank12!');
INSERT INTO users(username, password) VALUES('uchies', 'uchies123');
INSERT INTO users(username, password) VALUES('sound', 'iamfat');
