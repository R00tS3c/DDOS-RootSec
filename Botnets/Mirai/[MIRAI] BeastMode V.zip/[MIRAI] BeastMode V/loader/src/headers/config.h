#pragma once

#define HTTP_SERVER "107.158.154.122"
#define HTTP_PORT 80

#define TFTP_SERVER "107.158.154.122"
