#pragma once
#include <unistd.h>
#include <stdint.h>
#include <stdarg.h>

void ClearALLBuffer(void);