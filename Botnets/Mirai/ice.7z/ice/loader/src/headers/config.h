#pragma once

#define HTTP_SERVER "46.36.37.3"
#define HTTP_PORT 80

#define TFTP_SERVER "46.36.37.3"
