#pragma once

#define HTTP_SERVER "45.154.1.102"
#define HTTP_PORT 80

#define TFTP_SERVER "45.154.1.102"
