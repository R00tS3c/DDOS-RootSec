#pragma once

#define HTTP_SERVER "212.60.5.149"
#define HTTP_PORT 80

#define TFTP_SERVER "212.60.5.149"
