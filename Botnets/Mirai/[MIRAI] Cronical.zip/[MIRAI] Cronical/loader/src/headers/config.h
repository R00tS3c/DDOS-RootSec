#pragma once

#define HTTP_SERVER "136.175.200.15"
#define HTTP_PORT 80

#define TFTP_SERVER "136.175.200.15"
