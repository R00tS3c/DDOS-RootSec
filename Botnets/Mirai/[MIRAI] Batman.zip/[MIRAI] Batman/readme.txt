http://YourIP/index.php
to manage your users and other shit