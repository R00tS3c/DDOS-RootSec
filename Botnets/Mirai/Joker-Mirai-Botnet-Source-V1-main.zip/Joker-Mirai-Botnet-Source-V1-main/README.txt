I (USBBios A.K.A Tiger) did not create Joker V1. All credits go to IoTnet!

Enjoy though, #LeakedByTiger