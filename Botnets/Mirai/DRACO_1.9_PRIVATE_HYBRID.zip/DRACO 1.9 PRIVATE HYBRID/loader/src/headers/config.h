#pragma once

#define HTTP_SERVER "46.29.167.169"
#define HTTP_PORT 80

#define TFTP_SERVER "46.29.167.169"
