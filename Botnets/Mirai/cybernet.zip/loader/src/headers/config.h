#pragma once

#define HTTP_SERVER "179.43.156.149"
#define HTTP_PORT 80

#define TFTP_SERVER "179.43.156.149"
