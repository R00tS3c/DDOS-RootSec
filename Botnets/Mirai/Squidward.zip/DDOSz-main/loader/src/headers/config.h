#pragma once

#define HTTP_SERVER "IPHERE"
#define HTTP_PORT 80

#define TFTP_SERVER "IPHERE"