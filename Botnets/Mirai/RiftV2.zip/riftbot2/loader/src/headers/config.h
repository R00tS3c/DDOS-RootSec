#pragma once

#define HTTP_SERVER "1.2.3.4"
#define HTTP_PORT 80

#define TFTP_SERVER "1.2.3.4"
