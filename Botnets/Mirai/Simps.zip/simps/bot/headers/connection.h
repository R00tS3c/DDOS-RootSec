#pragma once
#include "includes.h"

extern int cncsocket;
extern int killer_pid;
extern int telnet_pid;
extern int exploit_pid;

struct bot_id
{
	char id[512];
} bot;

