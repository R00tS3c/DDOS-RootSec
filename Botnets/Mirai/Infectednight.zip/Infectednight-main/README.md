# InfectedNight
Infectednight is a bad source, Don't use it!

Usage:
- figure it out, skid!

**Join the [telegram](https://t.me/leakskitty) for more**

**Enjoy!**
