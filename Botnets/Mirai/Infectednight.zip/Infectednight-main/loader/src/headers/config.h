#pragma once

#define HTTP_SERVER "37.44.238.172"
#define HTTP_PORT 80

#define TFTP_SERVER "37.44.238.172"
