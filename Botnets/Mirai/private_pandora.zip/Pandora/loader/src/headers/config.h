#pragma once

#define HTTP_SERVER "167.99.202.142"
#define HTTP_PORT 80

#define TFTP_SERVER "167.99.202.142"
