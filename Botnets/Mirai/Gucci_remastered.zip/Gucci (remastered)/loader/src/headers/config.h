#pragma once

#define HTTP_SERVER "0.0.0.0" //Change this too your SERVER IP
#define HTTP_PORT 80

#define TFTP_SERVER "0.0.0.0" //Change this too your SERVER IP
