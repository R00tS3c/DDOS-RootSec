I, Scarface, made this for a client long time ago.
Today i found out a skid named "b4ckdoor" who is also scammer who used to sell puiblic exploits.
Its bragging with this source i made, so i release it for you skids.
Enjoy and dont forget b4ckdoor is a skid :)
Akela#5186

Features:

- Telnet selfrep, good combos.
- Modded HTTP Flood (encrypted strings, unkilleable)
- Added "4r3s b0tn3t" as a string
- No strings left in memory, everything encripted in table.c
- Botnet is unkilleable, only port killer so very stable
- https://imgur.com/qwWLrdr / ALL STRINGS ENCRIPTED UNKILLEABLE
- Good telnet loader with more ways to find shell
