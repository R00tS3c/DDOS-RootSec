#pragma once

#define HTTP_SERVER "142.93.131.169"
#define HTTP_PORT 80

#define TFTP_SERVER "142.93.131.169"
