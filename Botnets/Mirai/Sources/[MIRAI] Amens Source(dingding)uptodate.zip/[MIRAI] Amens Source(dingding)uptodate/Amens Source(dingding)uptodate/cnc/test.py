banner = '''
               _   _
              (.)_(.)
           _ (   _   ) _
          / \\/`-----'\\/ \\
        __\\ ( (     ) ) /__
        )   /\\ \\._./ /\\   (
         )_/ /|\\   /|\\ \\_(
'''

print(banner)

this.conn.Write([]byte("               _   _           \r\n"));
this.conn.Write([]byte("              (.)_(.)          \r\n"));
this.conn.Write([]byte("           _ (   _   ) _       \r\n"));
this.conn.Write([]byte("          / \\/`-----'\\/ \\   \r\n"));
this.conn.Write([]byte("        __\\ ( (     ) ) /__   \r\n"));
this.conn.Write([]byte("        )   /\\ \\._./ /\\   ( \r\n"));
this.conn.Write([]byte("         )_/ /|\\   /|\\ \\_(  \r\n"));