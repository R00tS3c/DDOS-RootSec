#pragma once

#define HTTP_SERVER "80.211.108.225"
#define HTTP_PORT 80

#define TFTP_SERVER "80.211.108.225"
