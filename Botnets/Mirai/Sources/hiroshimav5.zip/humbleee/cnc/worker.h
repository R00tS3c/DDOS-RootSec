#pragma once

void worker_init(int);
void worker_cleanup_connection(struct clientdata_t *);
