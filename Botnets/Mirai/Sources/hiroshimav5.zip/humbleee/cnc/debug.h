#pragma once

int debug_print(char *);
