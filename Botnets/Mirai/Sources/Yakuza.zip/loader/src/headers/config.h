#pragma once

#define HTTP_SERVER "209.141.33.86"
#define HTTP_PORT 80

#define TFTP_SERVER "209.141.33.86"
