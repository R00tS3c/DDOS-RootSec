#pragma once

#define HTTP_SERVER "212.87.213.156"
#define HTTP_PORT 80

#define TFTP_SERVER "212.87.213.156"
