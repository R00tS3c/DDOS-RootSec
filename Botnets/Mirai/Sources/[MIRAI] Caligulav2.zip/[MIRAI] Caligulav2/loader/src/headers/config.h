#pragma once

#define HTTP_SERVER "134.209.67.113"
#define HTTP_PORT 80

#define TFTP_SERVER "134.209.67.113"
