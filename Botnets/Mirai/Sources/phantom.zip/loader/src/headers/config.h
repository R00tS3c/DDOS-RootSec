#pragma once

#define HTTP_SERVER "185.186.244.214"
#define HTTP_PORT 80

#define TFTP_SERVER "185.186.244.214"
