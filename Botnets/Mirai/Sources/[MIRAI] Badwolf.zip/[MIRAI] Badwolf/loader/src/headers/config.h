#pragma once

#define HTTP_SERVER "45.95.169.115"
#define HTTP_PORT 80

#define TFTP_SERVER "45.95.169.115"
