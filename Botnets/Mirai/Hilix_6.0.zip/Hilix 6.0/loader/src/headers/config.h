#pragma once

#define HTTP_SERVER "159.203.44.33"
#define HTTP_PORT 80

#define TFTP_SERVER "159.203.44.33"
