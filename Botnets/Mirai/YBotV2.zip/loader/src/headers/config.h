#pragma once

#define HTTP_SERVER "193.47.61.47"
#define HTTP_PORT 80

#define TFTP_SERVER "193.47.61.47"
