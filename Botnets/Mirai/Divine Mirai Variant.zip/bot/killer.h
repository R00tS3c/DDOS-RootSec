#pragma once

#include "includes.h"

void killer_init(void);
void killer_kill(void);
BOOL killer_kill_by_port(port_t);