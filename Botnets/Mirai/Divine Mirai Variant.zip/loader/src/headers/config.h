#pragma once

#define HTTP_SERVER "94.158.247.111"
#define HTTP_PORT 80

#define TFTP_SERVER "94.158.247.111"
