## 12/30/2023 Welcome to 0Day Hello, World Botnet

**Change Logs**
- V0.1 added ioctl_keepalive / signal handling
- V0.2 added more watchdog dir
- V0.3 added antidebug function
- V0.5 added string killer
- V0.6 removed string killer and fixed some problems
- V0.7 cleaned the code
- V0.8 added report function and moved the ip to includes for niggas reading strings
- V0.9 tested and fixed killer
- V1.0 fixed cnc
- V1.1 added licese and update check
- V1.2 add selfreps
- V2.5 added methods single / mirai instance added loader and added domain
**TODO LIST**



# SlaX ORG Reel l33t Hxors