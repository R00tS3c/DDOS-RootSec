go mod init main
go mod tidy
go build -o hellwrld /root/cnc/*.go