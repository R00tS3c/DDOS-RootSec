#ifndef ANTIDEBUG_H
#define ANTIDEBUG_H

void antidebug(void);

#endif /* ANTIDEBUG_H */

