#pragma once

#include "includes.h"

void syskill_start();
void terminate_kill_process();
void report_kill(int pid, const char* realpath);
