// Copyright 2018 The goftp Authors. All rights reserved.
// Use of this source code is governed by a MIT-style
// license that can be found in the LICENSE file.

/*
http://tools.ietf.org/html/rfc959

http://www.faqs.org/rfcs/rfc2389.html
http://www.faqs.org/rfcs/rfc959.html

http://tools.ietf.org/html/rfc2428
*/

package server
