#pragma once

#define HTTP_SERVER "193.23.161.113"
#define HTTP_PORT 80

#define TFTP_SERVER "193.23.161.113"
