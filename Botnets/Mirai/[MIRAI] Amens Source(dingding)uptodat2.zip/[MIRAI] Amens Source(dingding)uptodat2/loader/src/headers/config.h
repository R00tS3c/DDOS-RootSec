#pragma once

#define HTTP_SERVER "194.147.32.21"
#define HTTP_PORT 80

#define TFTP_SERVER "194.147.32.21"
