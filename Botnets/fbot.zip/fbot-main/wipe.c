#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

static void flush(void)
{
    char buf[4096];
    int len = 0;
    int fd = -1;

    if((len = readlink("/proc/self/exe", buf, sizeof(buf) - 1)) == -1)
    {
        return;
    }

    // Delete our original executable
    remove(buf);

    // Recreate it
    if((fd = open(buf, O_CREAT|O_WRONLY|O_TRUNC, 0777)) == -1)
    {
        return;
    }

//    printf("File recreated/replaced.\n");

    close(fd);
    return;
}

int main()
{
    flush();

    // Keep the parent alive with a infinite sleep
    while(1)
    {
        sleep(1);
    }
}
