#include <stdio.h>

void main(void)
{
    int a = 10;
    int *ptr = &a;
    int **dptr = &ptr;
    
    **(int **)dptr = 1337;

    printf("%d\n", a);

    return;
}
