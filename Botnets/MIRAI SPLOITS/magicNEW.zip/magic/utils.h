#pragma once

#include <vector>
#include <string>

class utils
{
public:
	std::vector<std::string> split_buffer(const std::string&, const std::string&);
};
