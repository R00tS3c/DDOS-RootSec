package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
)

func main() {
	if len(os.Args) != 2 {
		fmt.Printf("Usage: %s [filename]\n", os.Args[0])
		os.Exit(1)
	}

	fileName := os.Args[1]
	file, err := os.Open(fileName)
	if err != nil {
		fmt.Printf("Error opening file %s: %v\n", fileName, err)
		os.Exit(1)
	}
	defer file.Close()

	// Create the file to write open ports
	openFile, err := os.Create("open.txt")
	if err != nil {
		fmt.Printf("Error creating file: %v\n", err)
		os.Exit(1)
	}
	defer openFile.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		ip := scanner.Text()
		go checkSSH(ip, openFile)
	}

	// Wait for all Goroutines to finish before exiting
	var input string
	fmt.Scanln(&input)
}

func checkSSH(ip string, openFile *os.File) {
	conn, err := net.DialTimeout("tcp", ip+":22", 2e9)
	if err == nil {
		fmt.Printf("%s: port 22 open\n", ip)
		// Write the IP address to the open file
		fmt.Fprintf(openFile, "%s\n", ip)
		conn.Close()
	} else {
		fmt.Printf("%s: port 22 closed\n", ip)
	}
}
