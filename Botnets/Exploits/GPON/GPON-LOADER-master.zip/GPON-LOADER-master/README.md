# GPON-LOADER
Exploit loader for Remote Code Execution w/ Payload on GPON Home Gateway devices (CVE-2018-10562) written in Python.

## Dependencies
`requests`

## Usage
```
python gpon-loader.py <list.txt>
```
