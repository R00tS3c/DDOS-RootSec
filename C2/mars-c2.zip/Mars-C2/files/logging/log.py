def log(func:str, text:str) -> None:
    print(f"[Log] -> ({func}) | {text}")
def error(func:str, text:str) -> None:
    print(f"[Log] -> ({func}) | {text}")
def fatial(func:str, text:str) -> None:
    print(f"[Log] -> ({func}) | {text}")