from x22 import main      # this comes from a compiled binary
main()