# L7 ENGINE

**Attack Args**

| Argument | Description | Value | Default |
| :-------- | :------------ | :------------ | :------------------------- |
| `humanization` | Browser activation | *true* or *false* | *false* | 
| `mode` | Attack mode | *http* or *socket* | *http* |
| `debug` | Develop | *true* or *false* | *false* | 
| `precheck` | Url to check proxies | *Custom url* or `https://httpbin.org/get` | `https://httpbin.org/get` | 
| `headers` | - | *string* of headers or *false* | *false* | 
| `postdata` | - | *string* of data or *false* | *false* | 
| `proxy` | Proxy url | *string* of proxy url or *string* | *string* | 
| `proxylen` | Number of proxies to check | number of proxies or *false* | *false* | 
| `time` | Attack duration | `120` or *false* | *false* | 
| `rate` | Numbers of requests per ip | `10` or `5` | `5` | 
| `pool` | Pool duration | `80` or `10` | `10` | 
| `statuscode` | - | `80` or *false* | *false* | 
| `pipelining` | Payload multiplication | `150` or `1` | `1` | 
| `uptime` | Proxies response time | `5000` or `10000` | `10000` | 
| `workers` | Browser multiplication | `120` or `15` | `15` | 
| `delay` | Requests sleep time | `0.5` or `0.1` | `0.1` | 
| `captcha` | Use of captcha | *true* or *false* | *false* | 
| `max_captchas` | Max captcha tries. | `1` or `5` | `5` | 


**Relevant parameters**

- `--mode`
- `--rate`
- `--pipelining`
- `--delay`
