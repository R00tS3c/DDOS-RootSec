console.clear();
const parsedArgs = require('minimist')(process.argv.slice(2));
const events = require('events');

process.on('uncaughtException', function(e) {
    //console.log(e);
}).on('unhandledRejection', function(e) {
    //console.log(e);
}).on('warning', e => {
    //console.log(e);
}).setMaxListeners(0);

events.EventEmitter.defaultMaxListeners = Infinity;
events.EventEmitter.prototype._maxListeners = Infinity;

process.on('SIGINT', function() {
    console.log( "\nBB down from SIGINT (Ctrl-C)" );
    process.exit(1);
});

function parse(string, results) {
    const result = /((?:"[^"]+[^\\]")|(?:'[^']+[^\\]')|(?:[^=]+))\s*=\s*("(?:[\s\S]*?[^\\])"|'(?:[\s\S]*?[^\\])'|(?:.*?[^\\])|$)(?:;|$)(?:\s*(.*))?/m.exec(string);
    if (result && result[1]) {
        const key = result[1].trim().replace(/(^\s*["'])|(["']\s*$)/g, '').toLowerCase();
        if (typeof result[2] === "string") {
            const val = result[2].replace(/(^\s*[\\]?["'])|([\\]?["']\s*$)/g, '');
            if (val === "") {
            } else if (val.toLowerCase() === "true") {
                results[key] = true;
            } else if (val.toLowerCase() === "false") {
                results[key] = false;
            } else {
                results[key] = val;
            }
        } else {
            results[result[1].trim()] = undefined;
        }
        if (result[3] && result[3].length > 1) {
            parse(result[3], results);
        }
    }
}

function parseHeaders(text){
    const object = {};
    parse(text, object);
    return object;
}

const usage = `<target> <options>`;

if (process.argv[2] == null || parsedArgs['help'] == true) {
    console.log(usage);
    process.exit(1);
}
    

var arguments = {
    target: process.argv[2],
    humanization: parsedArgs['humanization'] || 'false',
    mode: parsedArgs['mode'] || 'http',
    debug: parsedArgs['debug'] || 'false',
    precheck: parsedArgs['precheck'] || "https://httpbin.org/get",
    headers: parsedArgs['headers'] || 'false',
    postdata: parsedArgs['postdata'] || 'false',

	//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
    proxy: parsedArgs['proxy'] || 'HERE THE PROXY LIST',
	//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

    proxylen: parseInt(parsedArgs['proxylen']) || 'false',
    time: parseInt(parsedArgs['time']) || 'false',
    rate: parseInt(parsedArgs['rate']) || 5,
    pool: parseInt(parsedArgs['pool']) || 10,
    statuscode: parseInt(parsedArgs['statuscode']) || 'false',
    pipelining: parseInt(parsedArgs['pipelining']) || 1,
    uptime: parseInt(parsedArgs['uptime']) || 10000,
    workers: parseInt(parsedArgs['workers']) || 15,
    delay: parseInt(parsedArgs['delay']) || 0.5,
    captcha: parsedArgs['captcha'] || 'false',
    max_captchas: parseInt(parsedArgs['max_captchas']) || 5,
	
	//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
    token: parsedArgs['token'] || 'KEY 2 CAPTCHA HERE'
	//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
};

arguments.postdata = arguments.postdata == 'false' ? false : arguments.postdata;
arguments.headers = arguments.headers == 'false' ? 'false' : parseHeaders(arguments.headers);

if(arguments.time !== 'false'){
    setTimeout(() => {
        process.exit(4);
    }, (arguments.time * 1000));
}

function start(args){
    console.log(args);
    return require('./misc/proxies.js')(args);
}

start(arguments);